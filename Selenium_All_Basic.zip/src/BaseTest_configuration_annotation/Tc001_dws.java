package BaseTest_configuration_annotation;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class Tc001_dws extends BaseClass {

	String expectData="Books";
	@Test
	public void Tocheckbookpage() {
		driver.findElement(By.partialLinkText("Books")).click();
		String actualdata = driver.findElement(By.xpath("//h1[text()='Books']")).getText();
//		if(actualdata.equals(expectData)) {
//			Reporter.log("Navigated to book page successfully", true);
//		}else {
//			Reporter.log("failed to Navigated to book page", true);
//		}
		
		Assert.assertEquals(actualdata, expectData);
		Reporter.log("Navigated to book page successfully", true);
	}
	
}
