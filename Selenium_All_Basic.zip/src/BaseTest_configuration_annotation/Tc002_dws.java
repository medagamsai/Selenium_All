package BaseTest_configuration_annotation;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class Tc002_dws extends BaseClass{

	String expectData="Computers";
	@Test
	public void tocheckComputers() {
		driver.findElement(By.partialLinkText("Computers")).click();
		String actualData = driver.findElement(By.xpath("//h1[text()='Computers']")).getText();
//		if(actualData.equals(expectData)) {
//			Reporter.log("Navigated to computers page successfully", true);
//		}else {
//			Reporter.log("failed to Navigated to computers page", true);
//		}
		Assert.assertEquals(actualData, expectData);
		Reporter.log("Navigated to computers page successfully", true);
	}
}
