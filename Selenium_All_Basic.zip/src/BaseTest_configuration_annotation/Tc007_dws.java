package BaseTest_configuration_annotation;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class Tc007_dws extends BaseClass{

	String expectData="Demo Web Shop. Wishlist";
	@Test
	public void tocheckwishlist() {
		driver.findElement(By.xpath("//span[text()='Wishlist']")).click();
		String actualData = driver.getTitle();
		Assert.assertEquals(actualData, expectData);
		Reporter.log("Navigated to Wishlist page successfully", true);
	}
}
