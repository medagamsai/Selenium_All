package BaseTest_configuration_annotation;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class Tc006_dws extends BaseClass{

	String expectData="Shopping cart";
	@Test
	public void tocheckshoppingcart() {
		driver.findElement(By.xpath("//span[text()='Shopping cart']")).click();
		String actualData = driver.findElement(By.xpath("//h1[text()='Shopping cart']")).getText();
		Assert.assertEquals(actualData, expectData);
		Reporter.log("Navigated to shopping cart page successfully", true);
	}

}
