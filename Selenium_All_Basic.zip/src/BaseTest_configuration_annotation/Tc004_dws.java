package BaseTest_configuration_annotation;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class Tc004_dws extends BaseClass{

	String expectData="Cell phones";
	@Test
	public void tochecknews() throws InterruptedException {
//		WebElement electronic = driver.findElement(By.partialLinkText("Electronics"));
		Actions action = new Actions(driver);
		action.moveByOffset(584, 197).perform();
		driver.findElement(By.partialLinkText("Cell phones")).click();
		String actualData = driver.findElement(By.xpath("//h1[text()='Cell phones']")).getText();
		Assert.assertEquals(actualData, expectData);
		Reporter.log("Navigated to cellphone page successfully", true);
		
	}
}
