package BaseTest_configuration_annotation;

import org.openqa.selenium.By;
import org.testng.Reporter;
import org.testng.annotations.Test;

import dev.failsafe.internal.util.Assert;

public class Tc003_dws extends BaseClass {
	String expectData="News";
	@Test
	public void tochecknews() {
		driver.findElement(By.linkText("News")).click();
		String actualData = driver.findElement(By.xpath("//h1[text()='News']")).getText();
//		if(actualData.equals(expectData)) {
//			Reporter.log("Navigated to News page successfully", true);
//		}else {
//			Reporter.log("failed to Navigated to News page", true);
//		}
		org.testng.Assert.assertEquals(actualData,expectData);
		Reporter.log("Navigated to News page successfully", true);
		
	}

}
