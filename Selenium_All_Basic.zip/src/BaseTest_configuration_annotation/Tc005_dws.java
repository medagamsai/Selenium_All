package BaseTest_configuration_annotation;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class Tc005_dws extends BaseClass{
	String expectData="Search";
	@Test
	public void tochecksearch() {
		driver.findElement(By.id("small-searchterms")).sendKeys("iphone");
		driver.findElement(By.xpath("//input[@value='Search']")).click();
		String actualData = driver.findElement(By.xpath("//h1[text()='Search']")).getText();
		org.testng.Assert.assertEquals(actualData,expectData);
		Reporter.log("Navigated to product page successfully", true);
	}

}
