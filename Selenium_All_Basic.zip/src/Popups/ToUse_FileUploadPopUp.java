package Popups;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class ToUse_FileUploadPopUp {
//public static void main(String[] args) {
//	WebDriver driver = new ChromeDriver();
//	driver.manage().window().maximize();
//	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
//	
//	driver.get("https://www.naukri.com/registration/createAccount");
//	
//	driver.findElement(By.xpath("//h2[contains(text(),'experienced')]")).click();
//	
//	Actions action = new Actions(driver);
//	action.sendKeys(Keys.PAGE_DOWN).perform();
//	
//	driver.findElement(By.xpath("//button[text()='Upload Resume']")).sendKeys("C:\\Users\\LENOVO\\Downloads\\SELENIUM.pptx");
//}
	
	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://www.naukri.com/registration/createAccount");
		
		driver.findElement(By.xpath("//h2[contains(text(),'experienced')]")).click();
		
		Actions action = new Actions(driver);
		action.sendKeys(Keys.PAGE_DOWN).perform();
		
		driver.findElement(By.id("resumeUpload")).sendKeys("C:\\Users\\LENOVO\\Downloads\\Medagam Sai Krishna Resume.pdf");
	}
}
