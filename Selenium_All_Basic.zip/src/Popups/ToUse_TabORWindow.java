package Popups;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;

public class ToUse_TabORWindow {
//	public static void main(String[] args) throws IOException {
//		WebDriver driver = new ChromeDriver();
//		driver.manage().window().maximize();
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
//		
//		driver.get("https://www.amazon.in/");
//		WebElement search = driver.findElement(By.id("twotabsearchtextbox"));
//		search.sendKeys("iphone",Keys.ENTER);
//		
//		driver.findElement(By.xpath("//span[text()='Apple iPhone 13 (128GB) - Midnight' and @class='a-size-medium a-color-base a-text-normal']")).click();
//		Set<String> hand = driver.getWindowHandles();
//		System.out.println(hand);
//		String parent = driver.getWindowHandle();
//		System.out.println(parent);
//
//		for (String winHandle : hand) {
//		    if (!winHandle.equals(parent)) {
//		        driver.switchTo().window(winHandle);
//		    }
//		}
//		
//		TakesScreenshot ts = (TakesScreenshot)driver;
//		File temp = ts.getScreenshotAs(OutputType.FILE);
//		File src = new File("./errorShots/window.jpeg");
//		FileHandler.copy(temp, src);
//		
//	
//		
//	}
	
	public static void main(String[] args) throws IOException {
		WebDriver driver =new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://www.flipkart.com/");
		
		driver.findElement(By.name("q")).sendKeys("iphone 16",Keys.ENTER);
		driver.findElement(By.xpath("//div[text()='Apple iPhone 16 (Teal, 256 GB)']")).click();
		
		Set<String> allwin = driver.getWindowHandles();
		
		System.out.println(allwin);
		String childwin = driver.getWindowHandle();
		System.out.println(childwin);
		
		for(String allwindows : allwin) {
			if(allwindows.equals(childwin)) {
				driver.switchTo().window(allwindows);
			}
		}
		
		TakesScreenshot ts = (TakesScreenshot)driver;
		File temp = ts.getScreenshotAs(OutputType.FILE);
		File src = new File("./error/win.png");
		FileHandler.copy(temp, src);
	}

}
