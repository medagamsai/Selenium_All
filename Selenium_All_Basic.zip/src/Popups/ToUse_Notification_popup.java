package Popups;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class ToUse_Notification_popup {
//	public static void main(String[] args) {
//		ChromeOptions setting = new ChromeOptions();
////		setting.addArguments("--disable-notifications");
//		setting.addArguments("--incognito");
//		
//		WebDriver driver = new ChromeDriver(setting);
//		driver.manage().window().maximize();
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
//		
//		driver.get("https://www.yatra.com/");
//	}
	
	public static void main(String[] args) {
		ChromeOptions settings = new ChromeOptions();
//		settings.addArguments("--disable-notifications");

		settings.addArguments("--incognito");
		
		WebDriver driver = new ChromeDriver(settings);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://www.yatra.com/");
	}

}
