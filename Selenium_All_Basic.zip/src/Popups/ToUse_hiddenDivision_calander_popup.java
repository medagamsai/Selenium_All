package Popups;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class ToUse_hiddenDivision_calander_popup {
//	public static void main(String[] args) {
//		WebDriver driver = new ChromeDriver();
//		driver.manage().window().maximize();
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
//		
//		driver.get("https://www.makemytrip.com/");
//		driver.findElement(By.xpath("//span[@data-cy='closeModal']")).click();
//		driver.findElement(By.xpath("//p[@data-cy='departureDate']")).click();
//		
//		Actions action = new Actions(driver);		// no need
//		action.scrollByAmount(0, 100).perform();	// no need
//		
//		for(;;) {
//		try {
//		driver.findElement(By.xpath("//div[text()='March 2025']/../..//p[text()='26']")).click();
//		break;
//	}
//	catch (Exception e) {
//
//		driver.findElement(By.xpath("//span[@aria-label='Next Month']")).click();
//	}
//		}
//
//}
	
	public static void main(String[] args) {
		WebDriver driver= new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
		
		driver.get("https://www.makemytrip.com/");
		
		driver.findElement(By.xpath("//span[@data-cy='closeModal']")).click();
		driver.findElement(By.xpath("//label[@for='departure']")).click();
		
		for(;;) {
			try {
				driver.findElement(By.xpath("//div[text()='November 2025']/../..//p[text()='14']")).click();
			}
			catch (Exception e) {
				driver.findElement(By.xpath("//span[@aria-label='Next Month']")).click();
			}
		}
		
		
	}
}