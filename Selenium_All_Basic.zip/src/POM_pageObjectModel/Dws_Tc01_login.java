package POM_pageObjectModel;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Dws_Tc01_login {
//	public static void main(String[] args) {
//		
//		WebDriver driver = new ChromeDriver();
//		driver.manage().window().maximize();
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(12));
//		
//		driver.get("https://demowebshop.tricentis.com/");
//		
//		HomePage hp = new HomePage(driver);
//		hp.getLoginlink().click();
//		
//		LoginPage lp = new LoginPage(driver);
//		lp.getEmailtextfield().sendKeys("seleniumM4@gmail.com");
//		lp.getPasswordTextField().sendKeys("selenium@123");
//		lp.getLoginbutton().click();
//	}
	
	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://demowebshop.tricentis.com/");
		
		HomePage hp = new HomePage(driver);
		hp.getLoginlink().click();
		
		LoginPage lp = new LoginPage(driver);
		lp.getemailtextfield().sendKeys("sai123@gamil.com");
		lp.getpasswordtextfield().sendKeys("12345678");
		lp.getloginbutton().click();
		
	}

}
