package Iframe;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class ToUseIframe_Dream11 {
//	public static void main(String[] args) {
//		WebDriver driver = new ChromeDriver();
//		driver.manage().window().maximize();
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
//		
//		driver.get("https://www.dream11.com/");
//		
//		//switch to frame using index
////		driver.switchTo().frame(0);
//		
//		//switch to frame using id or name
////		driver.switchTo().frame("send-sms-iframe");
//		
//		//switch to frame using webelement
//		WebElement iframee = driver.findElement(By.xpath("//iframe[@title='Iframe Example']"));
//		driver.switchTo().frame(iframee);
//		
//		driver.findElement(By.id("regEmail")).sendKeys("9985598928");
//		
//		//switch back from fame
////		driver.switchTo().parentFrame();
//		driver.switchTo().defaultContent();
//		
//		driver.findElement(By.linkText("About Us")).click();
//		
//	}
	
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://www.dream11.com/");
		
		//by index
		driver.switchTo().frame(0);
		
		//by id or name
//		driver.switchTo().frame("send-sms-iframe");
		
		//by webelement
		
//		WebElement iframe = driver.findElement(By.xpath("//iframe[@title='Iframe Example']"));
//		driver.switchTo().frame(iframe);
		
		driver.findElement(By.id("regEmail")).sendKeys("9985598928");
		Thread.sleep(2000);
		
		driver.switchTo().defaultContent();
//		driver.switchTo().parentFrame();
		
		driver.findElement(By.linkText("About Us")).click();
		
		Thread.sleep(2000);
		driver.quit();
		
		
	}

}
