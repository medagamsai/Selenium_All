package Data_Driven;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ToUse_DataDriven {
//	public static void main(String[] args) throws IOException {
//		
//		//step 1 : create an object of FileInputStream
//		FileInputStream fis = new FileInputStream("./TestData/TestData.properties");
//		
//		//step 2 : create an object property file
//		Properties prop = new Properties();
//		
//		//step 3 : call method
//		prop.load(fis);
//		String URL = prop.getProperty("url");
//		String USERNAME = prop.getProperty("username");
//		String PASSWORD = prop.getProperty("password");
//		
//		//script
//		WebDriver driver = new ChromeDriver();
//		driver.manage().window().maximize();
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(12));
//		
//		driver.get(URL);
//		driver.findElement(By.name("username")).sendKeys(USERNAME);
//		driver.findElement(By.name("password")).sendKeys(PASSWORD);
//	}
	public static void main(String[] args) throws IOException {
		FileInputStream fis = new FileInputStream("./TestData/data.properties");
		
		Properties pro = new Properties();
		pro.load(fis);
		
		String URL = pro.getProperty("url");
		String UN = pro.getProperty("username");
		String PWD = pro.getProperty("password");
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get(URL);
		driver.findElement(By.name("username")).sendKeys(UN);
		driver.findElement(By.name("password")).sendKeys(PWD);
		
		
	}

}
