package Data_Driven;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;

import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.bouncycastle.openssl.EncryptionException;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Ignore;
import org.testng.annotations.Test;
public class ToReadDataFromExel {

//public static void main(String[] args)  throws EncryptionException, IOException {
//		
//		//Step 1:-Create obj of FIS
//		FileInputStream fis=new FileInputStream("./TestData/webshop.xlsx");
//		
//		//Step 2:- Create Object of Workbook
//		Workbook wb=WorkbookFactory.create(fis);
//		
//		//Step 3:- Call methods
//		String URl = wb.getSheet("Sheet1").getRow(0).getCell(0).toString();
//		String FIRSTNAME = wb.getSheet("Sheet1").getRow(1).getCell(0).getStringCellValue();
//		String LASTNAME = wb.getSheet("Sheet1").getRow(2).getCell(0).toString();
//		String EMAIL = wb.getSheet("Sheet1").getRow(3).getCell(0).toString();
//		String PASSWORD = wb.getSheet("Sheet1").getRow(4).getCell(0).toString();
//		String CONFIRM_PASSWORD = wb.getSheet("Sheet1").getRow(5).getCell(0).toString();
//		
//		
//		//Script
//		WebDriver driver=new ChromeDriver();
//		driver.manage().window().maximize();
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
//		
//		driver.get(URl);
//		driver.findElement(By.id("gender-male")).click();
//		driver.findElement(By.id("FirstName")).sendKeys(FIRSTNAME);
//		driver.findElement(By.name("LastName")).sendKeys(LASTNAME);
//		driver.findElement(By.id("Email")).sendKeys(EMAIL);
//		driver.findElement(By.id("Password")).sendKeys(PASSWORD);
//		driver.findElement(By.id("ConfirmPassword")).sendKeys(CONFIRM_PASSWORD,Keys.ENTER);
//		
//
//	}
	@Ignore
	@Test
	
	public void sai() throws EncryptedDocumentException, IOException {
		FileInputStream fis = new FileInputStream("./TestData/sai.xlsx");
		Workbook wb = WorkbookFactory.create(fis);
		
		String url = wb.getSheet("Sheet1").getRow(0).getCell(0).toString();
		String fn = wb.getSheet("Sheet1").getRow(1).getCell(0).getStringCellValue();
		String ln = wb.getSheet("Sheet1").getRow(2).getCell(0).toString();
		String em = wb.getSheet("Sheet1").getRow(3).getCell(0).toString();
		String pwd = wb.getSheet("Sheet1").getRow(4).getCell(0).toString();
		String cpwd = wb.getSheet("Sheet1").getRow(5).getCell(0).toString();
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get(url);
		driver.findElement(By.id("gender-male")).click();
		driver.findElement(By.id("FirstName")).sendKeys(fn);
		driver.findElement(By.id("LastName")).sendKeys(ln);
		driver.findElement(By.id("Email")).sendKeys(em);
		driver.findElement(By.id("Password")).sendKeys(pwd);
		driver.findElement(By.id("ConfirmPassword")).sendKeys(cpwd,Keys.ENTER);
		
		
	}
	
	@Test
	public void data() throws EncryptedDocumentException, IOException {
		FileInputStream fis = new FileInputStream("./TestData/sai.xlsx");
		Workbook wb = WorkbookFactory.create(fis);
		
		String link = wb.getSheet("Sheet1").getRow(0).getCell(0).toString();
		String un = wb.getSheet("Sheet1").getRow(1).getCell(0).toString();
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get(link);
	}
}
