package Locators;
// //tagname[@AN='AV']/axis::TAGNAME
public class ToUse_Xpath_axes {
// 1. //td[text()='kgf']/following-sibling::td			// younger
	
// 2.//td[text()='kgf']/preceding-sibling::td			// elder
	
// 3. //td[text()='kgf']/ancestor::tr
// 3.1 //td[text()='kgf']/ancestor::table				// parents...
}
