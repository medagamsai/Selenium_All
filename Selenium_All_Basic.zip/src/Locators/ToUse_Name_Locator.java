package Locators;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ToUse_Name_Locator {

//	public static void main(String[] args) throws InterruptedException {
//
//		ChromeDriver driver = new ChromeDriver();
//		driver.manage().window().maximize();
//		
//		driver.get("https://www.instagram.com/");
//		Thread.sleep(2000);
//		
//		driver.findElement(By.name("username")).sendKeys("sai");
//		Thread.sleep(2000);
//		
//		driver.findElement(By.name("password")).sendKeys("1234");
//		Thread.sleep(4000);
//		
//		driver.quit();
//		
//		}
	
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.instagram.com/");
		Thread.sleep(3000);
		
		driver.findElement(By.name("username")).sendKeys("sai123");
		Thread.sleep(2000);
		driver.quit();
	}

}
