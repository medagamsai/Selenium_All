package Locators;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ToUse_ClassName_Locator {

//	public static void main(String[] args) throws InterruptedException {
//
//		ChromeDriver driver = new ChromeDriver();
//		driver.manage().window().maximize();
//		
////		driver.get("https://www.instagram.com/");
////		Thread.sleep(2000);
////		
////		driver.findElement(By.className("_aa4b _add6 _ac4d _ap35")).sendKeys("sai@gmail.com"); // alpha numeric values not accept // so it is an error
////		Thread.sleep(2000);
//		
//		driver.get("https://demowebshop.tricentis.com/");
//		Thread.sleep(2000);
//		
//		driver.findElement(By.linkText("Log in")).click();
//		Thread.sleep(2000);
//		
//		driver.findElement(By.className("email")).sendKeys("sai@gmail.com");
//		Thread.sleep(2000);
//		
//		
//		driver.quit();
//	}
	
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://demowebshop.tricentis.com/login");
		Thread.sleep(2000);
		driver.findElement(By.className("email")).sendKeys("sai123");
		Thread.sleep(2000);
		driver.quit();
		
		}

}
