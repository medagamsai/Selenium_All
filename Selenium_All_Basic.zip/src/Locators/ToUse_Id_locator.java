package Locators;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class ToUse_Id_locator {

//	public static void main(String[] args) throws InterruptedException {
//
////		ChromeDriver driver = new ChromeDriver();
//		WebDriver driver = new EdgeDriver();
//		driver.manage().window().maximize();
//		
//		driver.get("https://www.facebook.com/");
//		Thread.sleep(3000);
//		
//		driver.findElement(By.id("email")).sendKeys("medagamsai@gmail.com");
//		Thread.sleep(3000);
//		
//		driver.findElement(By.id("pass")).sendKeys("123456");
//		Thread.sleep(5000);
//		
//
//		
//		driver.quit();
//
//	}
	
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.facebook.com/");
		driver.findElement(By.id("email")).sendKeys("sai");
		Thread.sleep(2000);
		driver.quit();
		
	}
	

}
