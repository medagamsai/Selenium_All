package Locators;
//tagname[@AN='AV' AND @AN='AV']
//tagname[@AN='AV' AND text()='AV']
//tagname[text()='AV' AND @AN='AV']
// and,or , not
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ToUse_Xpath_MultipleAttributes_AND_OR_NOT {
//	public static void main(String[] args) throws InterruptedException {
//		ChromeDriver driver = new ChromeDriver();
//		driver.manage().window().maximize();
//		
//		driver.get("https://demowebshop.tricentis.com/");
//		Thread.sleep(2000);
//		
//		driver.findElement(By.linkText("Log in")).click();
//		Thread.sleep(2000);
//		
//		driver.findElement(By.xpath("//input[@type='submit' and @value='Search']")).click();
//		Thread.sleep(2000);
//		
//		driver.quit();
//	}
	
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver= new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://demowebshop.tricentis.com/login");
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//input[@type='submit' and @value = 'Search']")).click();
		Thread.sleep(2000);
		driver.quit();
	}

}
