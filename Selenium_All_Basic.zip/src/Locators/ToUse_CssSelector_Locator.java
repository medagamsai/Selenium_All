package Locators;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ToUse_CssSelector_Locator {

//	public static void main(String[] args) throws InterruptedException {
//
//		ChromeDriver driver = new ChromeDriver();
//		driver.manage().window().maximize();
//		
//		driver.get("https://demowebshop.tricentis.com/");
//		Thread.sleep(2000);
//		
////		driver.findElement(By.cssSelector("input[type='submit']")).click();
//		driver.findElement(By.cssSelector("input[value='Search']")).click();
//		Thread.sleep(4000);
//		
//		driver.quit();
//	}
	
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demowebshop.tricentis.com/login");
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("input[type='submit']")).click();
		Thread.sleep(2000);
		driver.quit();
	}

}
