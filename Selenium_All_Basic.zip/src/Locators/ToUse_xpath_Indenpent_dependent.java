package Locators;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

//		//span[text()='ROADSTER']/../..//button[@id='addToCart']


public class ToUse_xpath_Indenpent_dependent {
//public static void main(String[] args) throws InterruptedException {
//	ChromeDriver driver = new ChromeDriver();
//	driver.manage().window().maximize();
//	
//	driver.get("https://www.shoppersstack.com/");
//	Thread.sleep(20000);
//	
//	driver.findElement(By.xpath("//span[text()='JOMPERS']/../..//button[@type='button']")).click();
//	Thread.sleep(3000);
//	
//	driver.quit();
//	
//}
	
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.shoppersstack.com/");
		Thread.sleep(15000);
		driver.findElement(By.xpath("//span[text()='FOREVER21']/../..//button[@id='addToCart']")).click();
		Thread.sleep(2000);
		driver.quit();
		
	}
}
