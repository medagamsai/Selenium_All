package Locators;
 // (xpath)[index]
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ToUse_Xpath_Index {
//	public static void main(String[] args) throws InterruptedException {
//		ChromeDriver driver = new ChromeDriver();
//		driver.manage().window().maximize();
//		
//		driver.get("https://www.dunzo.com/bangalore");
//		Thread.sleep(2000);
//		
//		driver.findElement(By.xpath("//p[text()='Search']")).click();
//		Thread.sleep(2000);
//		
//		driver.findElement(By.xpath("//input[contains(@placeholder,'Search for item or a store')]")).sendKeys("onion");
//		Thread.sleep(2000);
//		
//		driver.findElement(By.xpath("//input[contains(@placeholder,'Search for item or a store')]")).click();
//		Thread.sleep(2000);
//		
//		driver.findElement(By.xpath("(//p[text()='Onion'])[8]")).click();
//		Thread.sleep(4000);
//		
//		driver.quit();
//	}
	
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demowebshop.tricentis.com/login");
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//input[@type='submit'])[1]")).click();
		Thread.sleep(2000);
		driver.quit();
	}

}
