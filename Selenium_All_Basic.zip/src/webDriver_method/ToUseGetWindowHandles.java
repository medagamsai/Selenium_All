ackage webDriver_method;

import org.bouncycastle.est.ESTSourceConnectionListener;
import org.openqa.selenium.chrome.ChromeDriver;

public class ToUseGetWindowHandles {

	public static void main(String[] args) throws InterruptedException {

		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://web.whatsapp.com/");
		Thread.sleep(3000);
		
		driver.findElement();
		Thread.sleep(3000);
		Set<String> allWindowids = driver.getWindowHandles();
		System.out.println(allWindowids);
		
		driver.quit();
	}

}
