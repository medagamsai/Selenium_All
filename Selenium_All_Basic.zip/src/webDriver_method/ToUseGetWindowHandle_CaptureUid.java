package webDriver_method;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ToUseGetWindowHandle_CaptureUid {

//	public static void main(String[] args) throws InterruptedException {
//
//		ChromeDriver driver = new ChromeDriver();
//		driver.manage().window().maximize();
//		driver.get("https://www.instagram.com/");
//		String captureParentId = driver.getWindowHandle();
//		
//		System.out.println(captureParentId);
//		Thread.sleep(3000);
//		
//		driver.quit();
//	}
	
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.swiggy.com/");
		String handle=driver.getWindowHandle();
		System.out.println(handle);
		
		Thread.sleep(3000);
		
		driver.close();
	}

}
