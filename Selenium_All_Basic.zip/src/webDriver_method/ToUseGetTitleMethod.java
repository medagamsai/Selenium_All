package webDriver_method;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/* getTitle()
 ->use to capture title of the web page
 ->validation
 ->return type --> string
*/

public class ToUseGetTitleMethod {

//	public static void main(String[] args) {
//		
//ChromeDriver driver = new ChromeDriver(); // launche empty browser // starts server
//
//driver.get("https://www.instagram.com/accounts/login/");  //open instagram
////System.out.println(driver.getTitle());
//String titleofwebpage = driver.getTitle();
//System.out.println(titleofwebpage);				// print title of web page
//
//	}
	
	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.swiggy.com/");
		String titleofwebpage = driver.getTitle();
		System.out.println(titleofwebpage);
	}

}
