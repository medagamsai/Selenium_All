package webDriver_method;
import org.openqa.selenium.WebDriver;
/*
 * -> capture source code(html) of webpage
 * -> string 
 */
import org.openqa.selenium.chrome.ChromeDriver;

public class ToUseWebPageSourceMethod {

//	public static void main(String[] args) {
//		ChromeDriver driver = new ChromeDriver();
//		driver.get("https://www.swiggy.com/");
//		String sourcecode = driver.getPageSource();  // capture source code
//		System.out.println(sourcecode);
//
//	}
	
	public static void main(String[] args) {
		 WebDriver driver = new ChromeDriver();
		 driver.get("https://www.swiggy.com/");
		 String pagesource = driver.getPageSource();
		 System.out.println(pagesource);
		 driver.quit();
	}

}
