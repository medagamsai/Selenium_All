package webDriver_method;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
/*
 * -> managing (window(),timeouts(),cookies())
 * -> window ( maximize,minimize,fullscreen,getsize,setsize,getposition,setposition )
 * -> RT  Options
 */
import org.openqa.selenium.chrome.ChromeDriver;

public class ToUseManageMethod {

//	public static void main(String[] args) throws InterruptedException {
//
//		ChromeDriver driver = new ChromeDriver();
//		driver.get("https://www.swiggy.com/");
//		Thread.sleep(2000);
//		
//		// to maximize
////		driver.manage().window().maximize();
////		Thread.sleep(4000);
//		
//		// to minimize
////       driver.manage().window().minimize();
////		Thread.sleep(4000);
//		
//		// to fullscreen
////		driver.manage().window().fullscreen();
////		Thread.sleep(4000);
//		
//		// to capture size
////		Dimension sizeOfBrowser = driver.manage().window().getSize();
////		System.out.println(sizeOfBrowser); // get size of window (w,h)
////		Thread.sleep(4000);
//		
//		
//		
//		// to set size
//// 		Dimension d = new Dimension(200,100);
////		driver.manage().window().setSize(d);
////		driver.manage().window().setSize(new Dimension(200,300)); // width,height // setting the browser
////		Thread.sleep(4000);
//		
//		// to get position
////		Point position = driver.manage().window().getPosition();
////		System.out.println(position);
////		Thread.sleep(4000);
//		
//		
//		// to set position
//		
////		Point p = new Point(150,23);
////		driver.manage().window().setPosition(p);
//		
//		driver.manage().window().setPosition(new Point(123,234));
//		Thread.sleep(4000);
//		
//		driver.quit();
//
//	}
	
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.swiggy.com/");
//		driver.manage().window().fullscreen();
//		driver.manage().window().maximize();
//		driver.manage().window().minimize();
		
//		Dimension d = new Dimension(10, 20);
//		driver.manage().window().setSize(d);
		
//		Dimension d =driver.manage().window().getSize();
//		System.out.println(d);
		
//		Point position = driver.manage().window().getPosition();
//		System.out.println(position);
		
		Point setposition = new Point(150, 17);
		driver.manage().window().setPosition(setposition);
		
		Thread.sleep(3000);
		
		driver.quit();
	}

}
