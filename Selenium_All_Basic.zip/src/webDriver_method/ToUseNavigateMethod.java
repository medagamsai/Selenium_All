package webDriver_method;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.Navigation;
import org.openqa.selenium.chrome.ChromeDriver;

public class ToUseNavigateMethod {
//
//	public static void main(String[] args) throws InterruptedException, MalformedURLException {
//		
//		ChromeDriver driver = new ChromeDriver();
//		driver.manage().window().maximize();
//		
//		// to use to(string url)
////		driver.navigate().to("https://www.swiggy.com/"); // another way to open webpage // old one is get()
////		Thread.sleep(4000);
//		
//		
//		// to use to(URL url)
////		driver.navigate().to(new URL("https://www.swiggy.com/"));
////		Thread.sleep(4000);
//		
//		driver.get("https://www.swiggy.com/");
//		Thread.sleep(4000);
//		
//		// to use back,forward,refresh
//		
////		Navigation nav = driver.navigate();
////		nav.back();
////		Thread.sleep(4000);
////		nav.forward();
////		Thread.sleep(4000);
////		nav.refresh();
////		Thread.sleep(4000);
//				// approach2
//		driver.navigate().back();
//		Thread.sleep(2000);
//		driver.navigate().forward();
//		Thread.sleep(2000);
//		driver.navigate().refresh();
//		Thread.sleep(2000);
//		
//		
//
//		
//		driver.quit();
//
//	}

public static void main(String[] args) throws MalformedURLException, InterruptedException {
	WebDriver driver = new ChromeDriver();
	driver.manage().window().maximize();
//	driver.navigate().to("https://www.swiggy.com/");
//	driver.navigate().to(new URL("https://www.swiggy.com/"));
	driver.get("https://www.swiggy.com/");
	driver.navigate().forward();
	Thread.sleep(3000);
	driver.navigate().back();
	Thread.sleep(2000); 
	driver.navigate().refresh();
	Thread.sleep(2000);
	
	driver.quit();
}

}
