package webDriver_method;
/*
 * -> will close the browser (parent window)
 * -> will not stop server
 * -> RT ->void
 */
import org.openqa.selenium.chrome.ChromeDriver;

public class ToUseCloseMethod {

//	public static void main(String[] args) throws InterruptedException {
//		ChromeDriver driver = new ChromeDriver();
//		driver.get("https://www.swiggy.com/");
//		Thread.sleep(2000);
//		
//		driver.close();
//
//	}

}
