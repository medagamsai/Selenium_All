package webDriver_method;
/* getCurrentUrl()
->use to capture URL of the web page
->validation
->return type --> string
*/

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ToUseGetCurrentUrlMethod {

//	public static void main(String[] args) {
//		
//		ChromeDriver driver = new ChromeDriver();
//		driver.get("https://www.flipkart.com/");
//		String urlofthewebpage = driver.getCurrentUrl();
//		System.out.println(urlofthewebpage);
//
//	}
	
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.swiggy.com/");
		String url=driver.getCurrentUrl();
		System.out.println(url);
		Thread.sleep(3000);
		
		driver.quit();
	}

}
