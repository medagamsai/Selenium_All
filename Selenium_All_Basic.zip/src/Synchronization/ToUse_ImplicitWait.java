
package Synchronization;

import java.time.Duration;
import java.util.concurrent.ForkJoinPool.ManagedBlocker;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ToUse_ImplicitWait {
//	public static void main(String[] args) {
//		WebDriver driver = new ChromeDriver();
//		driver.manage().window().maximize();
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(14));
//		
//		driver.get("https://www.instagram.com/");
//		driver.findElement(By.name("username")).sendKeys("sai123@gmail.com");
//		driver.findElement(By.name("password")).sendKeys("sai1234567");
//		
//		driver.quit();
//	}
	
	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://www.instagram.com/");
		
		driver.findElement(By.name("username")).sendKeys("sai@123");
		driver.findElement(By.name("password")).sendKeys("123456");
		
		driver.quit();
	}
	
	

}
