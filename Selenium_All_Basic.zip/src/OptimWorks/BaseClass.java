package OptimWorks;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;

public class BaseClass {
	WebDriver driver;
	@BeforeClass
	public void browser(@Optional ("chrome") String bname) {
		if(bname.equalsIgnoreCase("chrome")) {
			driver=new ChromeDriver();
		}
		if(bname.equalsIgnoreCase("edge")) {
			driver = new EdgeDriver();
		}
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(4));
	}



@AfterClass
public void clodebrowser() {
	driver.quit();
}
}
