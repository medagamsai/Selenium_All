package OptimWorks;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

public class Amazon extends BaseClass{
	
	@Test(dataProvider = "sai")
	public void amazon(String link) throws InterruptedException, IOException {
		driver.get(link);
		try {
			driver.findElement(By.xpath("//button[@type='submit']")).click();
		} catch (Exception e) {
			System.out.println("sai");
		}
		
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys("laptop",Keys.ENTER);
		
		//All Product Name
		List<WebElement> data = driver.findElements(By.xpath("//div[@data-cy='title-recipe']"));
		for(WebElement s:data) {
			System.out.println(s.getText());
		}
		
		//All Product Price
		List<WebElement> pric = driver.findElements(By.xpath("//span[@class='a-price-whole']"));
		for(WebElement pe:pric) {
			System.out.println(pe.getText());
	
		}
		driver.findElement(By.xpath("//span[@id='a-autoid-0-announce']/span[2]")).click();
		driver.findElement(By.id("s-result-sort-select_1")).click();
		String onehandle = driver.getWindowHandle();
		driver.findElement(By.xpath("(//span[@class='a-price-whole'])[3]")).click();
		Set<String> allwin = driver.getWindowHandles();
		for(String win:allwin) {
			if(win!=onehandle) {
				driver.switchTo().window(win);
			}
		}
		
		String text = driver.findElement(By.id("productTitle")).getText();
		System.out.println("product Details "+text);
		String price = driver.findElement(By.xpath("//span[@id='productTitle']/../../../..//span[@class='a-price-whole']")).getText();
		System.out.println("product price "+price);
		
		//Taking Screen Short
		TakesScreenshot ts = (TakesScreenshot) driver;
		File temp = ts.getScreenshotAs(OutputType.FILE);
		File per = new File("./errorShots/amazon.png");
		org.openqa.selenium.io.FileHandler.copy(temp, per);
		
		//Used for Pagedown
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,300)");
		try {
			driver.findElement(By.id("add-to-cart-button")).click();
		} 
				
		
		catch (Exception e) {
			driver.findElement(By.xpath("(//input[@id='add-to-cart-button'])[2]")).click();
		}
		System.out.println("Product is Added to Cart Successfully");
	
		
	}
	
	@DataProvider(name="sai")
	public String[] dp() {
		String[] ud={"https://www.amazon.in/"};
		return ud;
	}
	
		@Ignore
		@Test
		public void sp() {
			driver.get("https://www.amazon.in/s?k=laptop");
			
			List<Integer> priceList = new ArrayList<>();
		
			List<WebElement> pric = driver.findElements(By.xpath("//span[@class='a-price-whole']"));
			for(WebElement pe:pric) {
			System.out.println(pe.getText());
			String me = pe.getText().replaceAll("[^\\d]", "");
			if(!me.isEmpty())
			priceList.add(Integer.parseInt(me));
			}
		Collections.sort(priceList);
		System.out.println(priceList);
		System.out.println(priceList.get(2));		//print 3rd element
			
			
			
		}
	
		@Ignore
		@Test
		public void dr() throws InterruptedException {
		// Step 1: Open Amazon laptop search results
		driver.get("https://www.amazon.in/s?k=laptop");

		// Step 2: Collect all price elements and their corresponding product containers
		List<WebElement> productContainers = driver.findElements(By.xpath("//div[contains(@data-component-type,'s-search-result')]"));
		List<Integer> priceList = new ArrayList<>();
		Map<Integer, WebElement> priceToContainer = new HashMap<>();

		for(WebElement product : productContainers) {
		    try {
		        String priceStr = product.findElement(By.xpath(".//span[@class='a-price-whole']")).getText().replaceAll("[^\\d]", "");
		        System.out.println(priceStr);
		        if(!priceStr.isEmpty()) {
		            int price = Integer.parseInt(priceStr);
		            priceList.add(price);
		            priceToContainer.put(price, product);
		        }
		    } catch (Exception e) {
		        // Sometimes products don't have prices listed, ignore those
		    }
		}

		// Step 3: Sort price list
		Collections.sort(priceList);

		// Step 4: Get 3rd smallest price (index 2)
		int thirdSmallestPrice = priceList.get(2);

		// Step 5: Select/click the third smallest product
		WebElement thirdProduct = priceToContainer.get(thirdSmallestPrice);
		// Typically, click on the product title or image to open details
		WebElement titleLink = thirdProduct.findElement(By.xpath("//h2[contains(@class,'a-size-medium a-spacing-none a-color-base a-text-normal')]"));
		titleLink.click();
		System.out.println(priceToContainer);
		Thread.sleep(5000);

		}

}
