package Basic;

import org.openqa.selenium.support.decorators.WebDriverDecorator;

public class Ba {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		



		        System.setProperty("webdriver.edge.driver", "C:\\WebDrivers\\msedgedriver.exe");
		        WebDriverDecorator driver = new WebDriverDecorator();
		        driver.get("https://www.google.com");
		    


	}

}
