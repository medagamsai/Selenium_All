package Basic;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class ToLauncheEmptyBrowser {

//	public static void main(String[] args) {
//		//ChromeDriver driver = new ChromeDriver(); // launche empty browser
//													// selenium server
////		EdgeDriver driver = new EdgeDriver();
//	//	WebDriver driver = new ChromeDriver();
//		WebDriver driver = new FirefoxDriver();
//
//	}
	
	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();
		
	}

}
