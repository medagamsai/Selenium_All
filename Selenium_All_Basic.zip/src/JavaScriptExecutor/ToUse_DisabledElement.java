package JavaScriptExecutor;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class ToUse_DisabledElement {
//	public static void main(String[] args) {
//		WebDriver driver = new ChromeDriver();
//		driver.manage().window().maximize();
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
//		
//		driver.get("https://www.oracle.com/java/technologies/downloads/");
//		driver.findElement(By.linkText("jdk-8u421-linux-aarch64.rpm")).click();
//		WebElement disabled = driver.findElement(By.linkText("Download jdk-8u421-linux-aarch64.rpm"));
//		
//		//to use JSE
//		JavascriptExecutor js = (JavascriptExecutor) driver;
//		js.executeScript("arguments[0].click()", disabled);
//		
//		
//		
//	}
	
	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://www.oracle.com/java/technologies/downloads/");
		
		driver.findElement(By.linkText("jdk-17.0.15_linux-aarch64_bin.tar.gz")).click();
		
		WebElement disabled = driver.findElement(By.linkText("Download jdk-17.0.15_linux-aarch64_bin.tar.gz"));
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click", disabled);
	}

}
