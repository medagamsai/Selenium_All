package JavaScriptExecutor;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ToUse_executeScript_scrollintoview {
//	public static void main(String[] args) {
//		WebDriver driver = new ChromeDriver();
//		driver.manage().window().maximize();
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
//		
//		JavascriptExecutor js = (JavascriptExecutor) driver;
//		driver.get("https://www.worldometers.info/geography/flags-of-the-world/#google_vignette");
//		WebElement indiaflag = driver.findElement(By.xpath("//img[@src='/img/flags/small/tn_in-flag.gif']"));
////		js.executeScript("arguments[0].scrollIntoView(true)", indiaflag);
//		js.executeScript("arguments[0].scrollIntoView(false)", indiaflag);
//	}
	
	public static void main(String[] args) {
		WebDriver driver =new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://www.worldometers.info/geography/flags-of-the-world/#google_vignette");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement flag = driver.findElement(By.xpath("//img[@alt='India']"));
	//	js.executeScript("arguments[0].scrollIntoView(true)", flag);
		js.executeScript("arguments[0].scrollIntoView(false)", flag);
	}
	

}
