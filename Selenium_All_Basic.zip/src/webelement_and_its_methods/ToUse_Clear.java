package webelement_and_its_methods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ToUse_Clear {
//	public static void main(String[] args) throws InterruptedException {
//		ChromeDriver driver = new ChromeDriver();
//		driver.manage().window().maximize();
//		
//		driver.get("https://demo.vtiger.com/vtigercrm/");
//		Thread.sleep(2000);
//		
//		WebElement usernameTextfield = driver.findElement(By.id("username"));
//		
//		usernameTextfield.clear();
//		usernameTextfield.sendKeys("sai");
//		Thread.sleep(2000);
//		
//		WebElement password = driver.findElement(By.id("password"));
//		password.clear();
//		password.sendKeys("1234");
//		
//		Thread.sleep(4000);
//		
//		driver.quit();
//	}
	
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://demo.vtiger.com/vtigercrm/");
		Thread.sleep(2000);
		
		WebElement userTextfield =driver.findElement(By.xpath("(//input[@value='admin'])[1]"));
		String text =userTextfield.getAttribute("value");
		System.out.println(text);
		userTextfield.clear();
		userTextfield.sendKeys("sai123");
		Thread.sleep(2000);
		
		
		WebElement password=driver.findElement(By.id("password"));
		password.clear();
		password.sendKeys("123456");
		
		Thread.sleep(2000);
		driver.quit();
		
		
		
	}

}
