package webelement_and_its_methods;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ToUse_GetSize {
//	public static void main(String[] args) throws InterruptedException {
//		ChromeDriver driver = new ChromeDriver();
//		driver.manage().window().maximize();
//		
//		driver.get("https://www.instagram.com/");
//		Thread.sleep(2000);
//		
//		Dimension sizeofWebElement = driver.findElement(By.xpath("//button[@type='submit']")).getSize();
//		System.out.println(sizeofWebElement);
//		System.out.println(sizeofWebElement.getWidth());
//		System.out.println(sizeofWebElement.getHeight());
//		
//		Thread.sleep(4000);
//		driver.quit();
//		
//	}
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.instagram.com/");
		Thread.sleep(2000);
		Dimension login = driver.findElement(By.xpath("//BUTTON[@type='submit']")).getSize();
		System.out.println(login);
		System.out.println(login.getHeight());
		System.out.println(login.getWidth());
		Thread.sleep(2000);
		driver.quit();
	}

}
