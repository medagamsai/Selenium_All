package webelement_and_its_methods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ToUse_GetTagName {
//	public static void main(String[] args) throws InterruptedException {
//		ChromeDriver driver = new ChromeDriver();
//		driver.manage().window().maximize();
//		
//		driver.get("https://www.actitime.com/");
//		Thread.sleep(2000);
//		
//		String tagname = driver.findElement(By.linkText("Try Free")).getTagName();
//		System.out.println(tagname);
//		Thread.sleep(4000);
//		
//		driver.quit();
//	}
	
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.instagram.com/");
		Thread.sleep(2000);
		String tagname = driver.findElement(By.xpath("//BUTTON[@type='submit']")).getTagName();
		System.out.println(tagname);
		driver.quit();
	}

}
