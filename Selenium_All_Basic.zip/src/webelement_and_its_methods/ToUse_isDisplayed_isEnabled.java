package webelement_and_its_methods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ToUse_isDisplayed_isEnabled {
//	public static void main(String[] args) throws InterruptedException {
//		ChromeDriver driver = new ChromeDriver();
//		driver.manage().window().maximize();
//		
//		driver.get("https://www.instagram.com/");
//		Thread.sleep(2000);
//		
//		WebElement loginButton = driver.findElement(By.xpath("//button[@type='submit']"));
//		System.out.println("before entering data");
//		System.out.println(loginButton.isDisplayed()); 		//true:exp
//		System.out.println(loginButton.isEnabled());		//false:exp
//		System.out.println(loginButton.isSelected()); 		//false:exp
//		System.out.println("===========================================================");
//		System.out.println("after entering data");
//		driver.findElement(By.name("username")).sendKeys("sai@123");
//		driver.findElement(By.name("password")).sendKeys("1234567");	// give more than 6 character
//		System.out.println(loginButton.isDisplayed()); 		//true:exp
//		System.out.println(loginButton.isEnabled());		//true:exp
//
//		
////		ChromeDriver driver = new ChromeDriver();
////		driver.manage().window().maximize();
////		
////		driver.get("https://demoapp.skillrary.com/");
////		Thread.sleep(3000);
////		
////		WebElement element = driver.findElement(By.xpath("//option[@value='90']"));
////		System.out.println("before selecting");
////		System.out.println(element.isSelected()); 		//false:exp
////		System.out.println("===========================================");
////		System.out.println("after selecting");
////		element.click();
////		System.out.println(element.isSelected());
////		
////		Thread.sleep(3000);
////		driver.quit();
//		
//		Thread.sleep(3000);
//		driver.quit();
//	}
	
	
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.instagram.com/");
		Thread.sleep(2000);
		System.out.println("before enter data");
		WebElement login = driver.findElement(By.xpath("//BUTTON[@type='submit']"));
		System.out.println(login.isDisplayed());
		System.out.println(login.isEnabled());
		System.out.println(login.isSelected());
		
		Thread.sleep(2000);
		System.out.println("after enter data");
		driver.findElement(By.name("username")).sendKeys("sai12345");
		driver.findElement(By.name("password")).sendKeys("123456789");
		
		System.out.println(login.isDisplayed());
		System.out.println(login.isEnabled());
		System.out.println(login.isSelected());
		driver.quit();
	}

}
