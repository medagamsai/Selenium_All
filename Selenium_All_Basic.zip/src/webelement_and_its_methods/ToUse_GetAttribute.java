package webelement_and_its_methods;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class ToUse_GetAttribute {
	public static void main(String[] args) throws InterruptedException {
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://www.actitime.com/");
		Thread.sleep(2000);
		
//		String value = driver.findElement(By.linkText("Try Free")).getAttribute("class"); // button header__button
		String value = driver.findElement(By.linkText("Try Free")).getAttribute("href"); // https://www.actitime.com/free-online-trial // it gives website link and AV
		System.out.println(value);
		Thread.sleep(4000);
		
		driver.quit();
	}

}
