package webelement_and_its_methods;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ToUse_GetLocation {
//	public static void main(String[] args) throws InterruptedException {
//		ChromeDriver driver = new ChromeDriver();
//		driver.manage().window().maximize();
//		
//		driver.get("https://www.instagram.com/");
//		Thread.sleep(2000);
//		
//		Point location = driver.findElement(By.xpath("//button[@type='submit']")).getLocation();
//		System.out.println(location);
//		System.out.println(location.getX());
//		System.out.println(location.getY());
//		
//		Thread.sleep(4000);
//		driver.quit();
//		
//	}
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.instagram.com/");
		Thread.sleep(2000);
		
		Point location =driver.findElement(By.xpath("//BUTTON[@type='submit']")).getLocation();
	System.out.println(location);
	System.out.println(location.getX());
	System.out.println(location.getY());
	
	driver.quit();
		
	}


}
