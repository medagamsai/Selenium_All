package DropDown_OR_ListBox_Handling;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class ToUseSingleSelect {
//	public static void main(String[] args) throws InterruptedException {
//		WebDriver driver = new ChromeDriver();
//		driver.manage().window().maximize();
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
//		
//		driver.get("https://www.facebook.com/r.php");
//		
//		// identify dropdown
//		WebElement dayDropDown = driver.findElement(By.id("day"));
//		WebElement monthDropDown = driver.findElement(By.id("month"));
//		WebElement yearDropDown = driver.findElement(By.id("year"));
//		
//		//handle drop down
//		Select dayselect = new Select(dayDropDown);
//		Select monthselect = new Select(monthDropDown);
//		Select yearselect = new Select(yearDropDown);
//		
//		
//		//call methods
//		dayselect.selectByIndex(19);
//		monthselect.selectByValue("4");
//		yearselect.selectByVisibleText("2002");
//		
//		//select multiple or not
////		System.out.println(dayselect.isMultiple());
////		System.out.println(monthselect.isMultiple());
//		
//		//to Capture all options in dropdown
//		List<WebElement> allmonths = monthselect.getOptions();
//		for(WebElement month : allmonths) {
//			System.out.println(month.getText());
//			monthselect.selectByVisibleText(month.getText());	//magic
//			Thread.sleep(2000);
//		}
//		
//		driver.quit();
//	}
	
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://www.facebook.com/r.php");
		
		WebElement dayidentify = driver.findElement(By.id("day"));
		WebElement monthidentify = driver.findElement(By.id("month"));
		WebElement yearidentify = driver.findElement(By.id("year"));
		
		Select dayselect = new Select(dayidentify);
		Select monthselect = new Select(monthidentify);
		Select yearselect = new Select(yearidentify);
		
		dayselect.selectByIndex(19);
		monthselect.selectByValue("4");
		yearselect.selectByVisibleText("2002");
		
		System.out.println(dayselect.isMultiple());
		System.out.println(monthselect.isMultiple());
		
		List<WebElement> allmonths = monthselect.getOptions();
		for(WebElement month : allmonths) {
			System.out.println(month.getText());
			monthselect.selectByVisibleText(month.getText());
			Thread.sleep(1000);
		}
		
		
		Thread.sleep(2000);
		driver.quit();
		
	}

}
