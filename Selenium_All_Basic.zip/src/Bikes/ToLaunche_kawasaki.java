package Bikes;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class ToLaunche_kawasaki {

	@Test(groups = "system")
	public void kawasaki() {
		WebDriver driver = new ChromeDriver();
		driver.get("https://kawasaki-india.com/bikes/ninja-300/");
		Reporter.log("kawasaki got launched", true);
		driver.quit();
	}
}
