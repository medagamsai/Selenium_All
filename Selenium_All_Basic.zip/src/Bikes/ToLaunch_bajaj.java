package Bikes;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class ToLaunch_bajaj {

	
	@Test(groups = "smoke")
	public void bajaj() {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.bikewale.com/bajaj-bikes/platina/");
		Reporter.log("bajaj got launched", true);
		driver.quit();
	}

}
