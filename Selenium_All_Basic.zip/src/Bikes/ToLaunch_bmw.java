package Bikes;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class ToLaunch_bmw {
	
	@Test(groups = "smoke")
	public void bmw() {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.bmw-motorrad.in/en/models/modeloverview.html");
		Reporter.log("BMW got launched", true);
		driver.quit();
	}

}
