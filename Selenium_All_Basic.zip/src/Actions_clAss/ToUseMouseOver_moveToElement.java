package Actions_clAss;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class ToUseMouseOver_moveToElement {
//	public static void main(String[] args) {
//		WebDriver driver = new ChromeDriver();
//		driver.manage().window().maximize();
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
//		driver.get("https://www.flipkart.com/");
//		
//		WebElement electronicsele = driver.findElement(By.xpath("//span[text()='Login']"));
//		
//		//to use actions class
//		Actions action = new Actions(driver);
//		action.moveToElement(electronicsele).perform();
//	}
	
	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://www.flipkart.com/");
		
		WebElement login = driver.findElement(By.xpath("//span[text()='Login']"));
		Actions action = new Actions(driver);
		action.moveToElement(login).perform();
	}

}
