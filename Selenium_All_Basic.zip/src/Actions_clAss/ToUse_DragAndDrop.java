package Actions_clAss;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class ToUse_DragAndDrop {
//	public static void main(String[] args) throws InterruptedException {
//		WebDriver driver = new ChromeDriver();
//		driver.manage().window().maximize();
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
//		
//		driver.get("https://www.globalsqa.com/demo-site/draganddrop/");
//		
//		
//		// to swith to frame
//		WebElement iframe = driver.findElement(By.xpath("//iframe[@class='demo-frame lazyloaded']"));
//		driver.switchTo().frame(iframe);
//		
//		//identify all the images
//		WebElement img1 = driver.findElement(By.xpath("//img[@alt='The peaks of High Tatras']"));
//		WebElement img2 = driver.findElement(By.xpath("//img[@alt='The chalet at the Green mountain lake']"));
//		WebElement img3 = driver.findElement(By.xpath("//img[@alt='Planning the ascent']"));
//		WebElement img4 = driver.findElement(By.xpath("//img[@alt='On top of Kozi kopka']"));
//		
//		//identyfy trash
//		WebElement trash = driver.findElement(By.id("trash"));
//		
//		//drag images to trash box
//		
//		Actions action = new Actions(driver);
//		action.dragAndDrop(img1, trash).perform();
//		Thread.sleep(2000);
////		action.dragAndDrop(img2, trash).perform();
//		action.dragAndDropBy(img2, 500, 0).perform();							// DragAndDropBy
//		Thread.sleep(2000);
////		action.dragAndDrop(img3, trash).perform();
//		action.clickAndHold(img3).moveToElement(trash).release().perform();
//		Thread.sleep(2000);
//		action.dragAndDrop(img4, trash).perform();
//		Thread.sleep(2000);
//		
//		//draganddrop trash to gallary
//		
//		WebElement gallary = driver.findElement(By.id("gallery"));
//		
//		action.dragAndDrop(img1, gallary).perform();
//		Thread.sleep(2000);
//		action.dragAndDrop(img2, gallary).perform();
//		Thread.sleep(2000);
//		action.dragAndDrop(img3, gallary).perform();
//		Thread.sleep(2000);
//		action.dragAndDrop(img4, gallary).perform();
//		
//		
//		driver.switchTo().defaultContent();
//		driver.findElement(By.xpath("(//a[text()='AlertBox'])[2]")).click();
//		
//		
//	}
	
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://www.globalsqa.com/demo-site/draganddrop/");
		
		WebElement iframe = driver.findElement(By.xpath("//iframe[@class='demo-frame lazyloaded']"));
		driver.switchTo().frame(iframe);
		
		WebElement img1 = driver.findElement(By.xpath("//img[@alt='The peaks of High Tatras']"));
		WebElement img2 = driver.findElement(By.xpath("//img[@alt='The chalet at the Green mountain lake']"));
		WebElement img3 = driver.findElement(By.xpath("//img[@alt='Planning the ascent']"));
		WebElement img4 = driver.findElement(By.xpath("//img[@alt='On top of Kozi kopka']"));
		
		
		WebElement trash = driver.findElement(By.id("trash"));
		
		Actions action = new Actions(driver);
		action.dragAndDrop(img1, trash).perform();
		Thread.sleep(2000);
		action.clickAndHold(img2).moveToElement(trash).release().perform();
		Thread.sleep(2000);
		action.dragAndDropBy(img3, 500, 0).perform();
		Thread.sleep(2000);
		
		action.dragAndDrop(img4, trash).perform();
		Thread.sleep(2000);
		
		WebElement gallary = driver.findElement(By.id("gallery"));
		
		action.dragAndDrop(img1, gallary).perform();
		Thread.sleep(2000);
		action.clickAndHold(img2).moveToElement(gallary).release().perform();
		Thread.sleep(2000);
		action.dragAndDrop(img3, gallary).perform();
		Thread.sleep(2000);
		action.dragAndDrop(img4, gallary).perform();
		Thread.sleep(2000);
		driver.switchTo().defaultContent();
		
		driver.findElement(By.linkText("AlertBox")).click();
		Thread.sleep(2000);
		driver.quit();
		
	}

}
