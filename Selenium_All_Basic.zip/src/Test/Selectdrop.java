package Test;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.List;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Selectdrop {

public static void main(String[] args) throws EncryptedDocumentException, IOException {
	FileInputStream fis = new FileInputStream("./TestData/sai2.xlsx");
	Workbook wb = WorkbookFactory.create(fis);
	
	String link = wb.getSheet("Sheet1").getRow(3).getCell(0).toString();
	
	WebDriver driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	
	driver.get(link);
	
	WebElement day = driver.findElement(By.id("day"));
	WebElement mon = driver.findElement(By.id("month"));
	WebElement year = driver.findElement(By.id("year"));
	
	
Select days = new Select(day);
Select mont = new Select(mon);
Select yearr = new Select(year);

days.selectByIndex(19);
mont.selectByValue("4");
yearr.selectByVisibleText("2002");

List<WebElement> allmon = mont.getOptions();
for (WebElement month:allmon) {
	mont.selectByVisibleText(month.getText());
	
	
}

 
   
	
}
}
