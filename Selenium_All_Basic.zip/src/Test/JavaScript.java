package Test;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class JavaScript {
	public static void main(String[] args) throws EncryptedDocumentException, IOException {
		FileInputStream fis = new FileInputStream("./TestData/sai2.xlsx");
		Workbook wb = WorkbookFactory.create(fis);
	String link = wb.getSheet("Sheet1").getRow(3).getCell(0).toString();
	WebDriver driver=new ChromeDriver();
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
	driver.get(link);
	
	
	JavascriptExecutor je= (JavascriptExecutor) driver;
	WebElement cust = driver.findElement(By.id("custom_gender"));
	je.executeScript("arguments[0].value='have'", cust);
	
	
//	driver.findElement(By.xpath("//span[@class='d-ib ico ico-modern ico-images img']")).click();
//	
//	
//	for(;;) {
//		try {
//			driver.findElement(By.id("yui_3_5_1_1_1757167747788_1625")).click();
//			break;
//		}
//		catch (Exception e) {
////			je.executeScript("window.scrollBy(0,500)");
//			je.executeScript("window.scrollBy(0,500)");
//		}
//	}
//	WebElement us = driver.findElement(By.xpath("//span[text()='U.S.']"));
//	je.executeScript("arguments[0].scrollIntoView(false)", us);
		
	}

}
