package Test;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Locations {
public static void main(String[] args) throws EncryptedDocumentException, IOException {
	FileInputStream fis = new FileInputStream("./TestData/sai1.xlsx");
	Workbook wb = WorkbookFactory.create(fis);
	
	String link = wb.getSheet("Sheet1").getRow(0).getCell(0).toString();
	String name = wb.getSheet("Sheet1").getRow(1).getCell(0).toString();
	
	WebDriver driver = new ChromeDriver();

	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	driver.get(link);
//	driver.findElement(By.name("username")).sendKeys(name);
	driver.findElement(By.xpath("//input[@name='username']")).sendKeys(name);
	driver.findElement(By.xpath("//input[@name='password' and @type='password']")).sendKeys("12345");
	driver.findElement(By.xpath("//span[text()='Sign up']")).click();
	
	
}

}
