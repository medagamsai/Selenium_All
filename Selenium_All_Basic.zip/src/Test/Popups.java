package Test;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Popups {
	public static void main(String[] args) throws EncryptedDocumentException, IOException {
//		ChromeOptions settings = new ChromeOptions();
//		settings.addArguments("--incognito");
		FileInputStream fis=new FileInputStream("./TestData/sai2.xlsx");
		Workbook wb = WorkbookFactory.create(fis);
	String link = wb.getSheet("Sheet1").getRow(7).getCell(0).toString();
//	WebDriver driver = new ChromeDriver(settings);
	WebDriver driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	driver.get(link);
	driver.findElement(By.xpath("//span[@data-cy='closeModal']")).click();
	driver.findElement(By.xpath("//span[text()='Departure']")).click();
	for(;;) {
		try {
			driver.findElement(By.xpath("//div[text()='February 2026']/../..//p[text()='13']")).click();
		} catch (Exception e) {
			driver.findElement(By.xpath("//span[@aria-label='Next Month']")).click();
		}
	}
//	driver.findElement(By.xpath("//h2[contains(text(),'experienced')]")).click();
//	driver.findElement(By.id("resumeUpload")).sendKeys("C:\\Users\\LENOVO\\Downloads\\MedagamSaiKrishnaReddyResume.pdf");
	
	}

}
