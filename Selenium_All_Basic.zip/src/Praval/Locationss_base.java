package Praval;

import java.time.Duration;

import org.apache.xmlbeans.impl.xb.xsdschema.Public;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;

import com.beust.jcommander.Parameters;

public class Locationss_base {

WebDriver driver;
String exphomepage="Demo Web Shop";
@org.testng.annotations.Parameters("browser")
@BeforeClass
public void tolaunch(@Optional("chrome")String bname) {
	if(bname.equalsIgnoreCase("chrome")) {
		driver=new ChromeDriver();
	}
	else if(bname.equalsIgnoreCase("edge")) {
		driver = new FirefoxDriver();
	}
	Reporter.log("browser got launched",true);
	driver.manage().window().maximize();
	Reporter.log("browser got maximized",true);
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
}
@AfterClass
public void closebrow() {
	
	Reporter.log("browser closed",true);
	driver.quit();
	
}
@BeforeMethod
public void login() {
	driver.get("https://demowebshop.tricentis.com/");
	String acthomepage = driver.getTitle();
	if(acthomepage.equals(exphomepage)) {
		Reporter.log("navigated to homepage successfully",true);
	}else
		Reporter.log("error occure to navigate to homepage",true);
	driver.findElement(By.linkText("Log in")).click();
	driver.findElement(By.id("Email")).sendKeys("medagam@gmail.com");
	driver.findElement(By.id("Password")).sendKeys("123456");
	driver.findElement(By.xpath("//input[@value='Log in']")).click();
	Reporter.log("login successfull",true);
	
	
}
@AfterMethod
public void logout() {
	driver.findElement(By.linkText("Log out")).click();
	Reporter.log("logout successfully",true);
}


}
