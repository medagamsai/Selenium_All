package Praval;

import java.io.IOException;
import java.time.Duration;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.hslf.record.InteractiveInfoAtom.Link;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

public class Baseinsta extends TestDataexcel{
	public Baseinsta() throws EncryptedDocumentException, IOException {
		super();
		// TODO Auto-generated constructor stub
	}
	WebDriver driver;
	String exp = "Instagram";
//	@Parameters("browser")
	@BeforeClass
	public void tolaunchbrowser(@Optional("chrome")String bname) {
		if(bname.equalsIgnoreCase("chrome")) {
			driver = new ChromeDriver();
		}
		if(bname.equalsIgnoreCase("firefox")) {
			driver = new FirefoxDriver();
		}
		Reporter.log("browser got launched",true);
		driver.manage().window().maximize();
		Reporter.log("windows maximized",true);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	}
	@AfterClass
	public void closebrowser() {
		Reporter.log("browser got closed",true);
		driver.quit();
	}
	@BeforeMethod
	public void login() throws EncryptedDocumentException, IOException {
		TestDataexcel();
//		TestDataexcel ex=new TestDataexcel();
		driver.get(link);
		String org = driver.getTitle();
		if(org.equals(org))
			Reporter.log("application open navigated",true);
		else
			Reporter.log("navigation failed app",true);
		driver.findElement(By.name("username")).sendKeys(un);
		Reporter.log("username entered",true);
		driver.findElement(By.name("password")).sendKeys(pwd);
		Reporter.log("pwd is entered",true);
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		Reporter.log("login successfull",true);
		
	}
	private void TestDataexcel() {
		// TODO Auto-generated method stub
		
	}
	@AfterMethod
	public void logout () {
		Reporter.log("logout success",true);
	}

}
