package Praval;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class TestDataexcel {
public String link;
public String un;
public String pwd;
	public TestDataexcel() throws EncryptedDocumentException, IOException {

		FileInputStream fis = new FileInputStream("./TestData/saimee.xlsx");
		Workbook wb = WorkbookFactory.create(fis);
		this.link = wb.getSheet("Sheet1").getRow(0).getCell(0).toString();
		this.un = wb.getSheet("Sheet1").getRow(1).getCell(0).toString();
		this.pwd = wb.getSheet("Sheet1").getRow(2).getCell(0).toString();
		fis.close();
	}

}
