package Praval;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class Demo_tc001 extends Locationss_base {

	String exp="Books";
	
	@Test
	public void bookspage() {
		driver.findElement(By.partialLinkText("Books")).click();
		String org = driver.findElement(By.xpath("//h1[text()='Books']")).getText();
		Assert.assertEquals(org, exp);
		Reporter.log("Navigated to books page",true);
	}
	
}
