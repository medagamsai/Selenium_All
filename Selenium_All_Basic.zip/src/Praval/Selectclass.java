package Praval;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Selectclass {

	public static void main(String[] args) {

		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		
		driver.get("https://www.facebook.com/r.php");
	WebElement day = driver.findElement(By.id("day"));
		WebElement month = driver.findElement(By.id("month"));
		WebElement year = driver.findElement(By.id("year"));
		
		Select daysel = new Select(day);
		Select monsel=new Select(month);
		Select yearsel = new Select(year);
		
		daysel.selectByIndex(19);
		monsel.selectByValue("4");
		yearsel.selectByVisibleText("2002");
		
		List<WebElement> allmon = monsel.getOptions();
		for ( WebElement mon:allmon) {
			System.out.println(mon.getText());
			monsel.selectByVisibleText(mon.getText());
			
			
		}
	}

}
