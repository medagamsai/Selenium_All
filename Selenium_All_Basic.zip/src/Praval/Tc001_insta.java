package Praval;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.logging.FileHandler;


import org.apache.poi.EncryptedDocumentException;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;


public class Tc001_insta extends Baseinsta {
	public Tc001_insta() throws EncryptedDocumentException, IOException {
		super();
		// TODO Auto-generated constructor stub
	}
	String exp="Instagram";
	@Test
	public void in() {
		String org = driver.getTitle();
		Assert.assertEquals(org, exp);
		Reporter.log("working fine",true);
	}
	@Test
	public void Screenshort() throws IOException, InterruptedException {
		
	
		
		TakesScreenshot ts = (TakesScreenshot)driver;
		File temp = ts.getScreenshotAs(OutputType.FILE);
		File per = new File("./error/insta1.png");
		org.openqa.selenium.io.FileHandler.copy(temp, per);
		Reporter.log("image stored",true);
		
	}
	
	@Test
	public void screenelement() throws IOException  {
	
		File temp = driver.findElement(By.name("password")).getScreenshotAs(OutputType.FILE);
		File org = new File("./error/insta2.png");
		Files.copy(temp.toPath(), org.toPath());
		Reporter.log("done",true);
		
	}

}
