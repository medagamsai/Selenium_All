package Assignment;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class Task14_xpath_closePopUpWindow {
	public static void main(String[] args) throws InterruptedException {
		int totalSleep=20000;
		int currentSleep=3000;
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://www.woodenstreet.com/");
		//Thread.sleep(20000);
		for(int i = 0;i<=totalSleep;i+=currentSleep) {
			Thread.sleep(currentSleep);
		}
		
		driver.findElement(By.xpath("//div[@id='loginclose1']")).click();
		Thread.sleep(2000);
		driver.quit();
	}

}
