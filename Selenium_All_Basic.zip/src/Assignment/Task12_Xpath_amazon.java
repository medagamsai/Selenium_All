package Assignment;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class Task12_Xpath_amazon {

	public static void main(String[] args) throws InterruptedException {

		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://www.amazon.in/");
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//input[@placeholder='Search Amazon.in']")).sendKeys("cricket bat");
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//input[@value='Go']")).click();
		Thread.sleep(4000);
		
		driver.quit();
	}

}
