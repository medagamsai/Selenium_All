package Assignment;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class Task16_AddToCart {
	public static void main(String[] args) throws InterruptedException {
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://www.woodenstreet.com/");
		for(int i = 0;i<=12000;i+=3000) {
		Thread.sleep(3000);
		}
		driver.findElement(By.xpath("//div[@id='loginclose1']")).click();
		driver.findElement(By.linkText("Sofas")).click();
		driver.findElement(By.xpath("//p[text()='Wooden Sofa Sets']")).click();
		driver.findElement(By.xpath("(//h3[contains(text(),'Sheesham') and @class='heading'])[1]")).click();
		driver.findElement(By.xpath("//a[@id='button-cart-buy-now']")).click();
		
		
		Thread.sleep(3000);
		driver.quit();
		
	}

}
