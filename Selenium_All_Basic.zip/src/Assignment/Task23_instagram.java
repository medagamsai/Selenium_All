package Assignment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Task23_instagram {
	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://www.instagram.com/");
		// without using thread.sleep			error
		driver.findElement(By.name("username")).sendKeys("sai123@gmail.com");
		driver.findElement(By.name("password")).sendKeys("12345678");
	}

}
