package Assignment;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class Task19_fb_logo_display {
	public static void main(String[] args) throws InterruptedException {
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://www.facebook.com/");
		Thread.sleep(2000);
		
		boolean display = driver.findElement(By.xpath("//img[@alt='Facebook']")).isDisplayed();
		if(display==true) {
			System.out.println("FaceBook logo is displayed");
		}
		else {
			System.out.println("FaceBook logo is not displayed");
		}
		
		
		driver.quit();
	}

}
