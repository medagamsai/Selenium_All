package Assignment;
/*
 * -> NAVIGATE TO POLAR BEAR APPLICATION
 * -> CAPTURE THE TITLE OF THE WEBPAGE
 * -> PRINT IT IN CONSOLE (OUTPUT)
 * -> CLOSE THE BROWSER
 */
import org.openqa.selenium.chrome.ChromeDriver;

public class Task1 {

	public static void main(String[] args) {
		
		ChromeDriver driver = new ChromeDriver();
		
		driver.get("https://polarbear.co.in/franchisee/");
		String titleOfThePolarBear = driver.getTitle();
		System.out.println(titleOfThePolarBear);
		
		driver.close();

	}

}
