package Assignment;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Task18_myntra_allpro {
	public static void main(String[] args) throws InterruptedException {
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://www.myntra.com/");
		Thread.sleep(2000);
		
		List<WebElement> store = driver.findElements(By.xpath("//nav[@class='desktop-navbar']/div/div"));
		
		for(WebElement w : store) {
			System.out.println(w.getText());
			
		}
		Thread.sleep(2000);
		driver.quit();
	}
	
}
