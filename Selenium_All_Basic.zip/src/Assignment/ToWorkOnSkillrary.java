package Assignment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ToWorkOnSkillrary {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();		//upcasting
		driver.manage().window().maximize();
		
		
		driver.get("https://demoapp.skillrary.com/");
		Thread.sleep(2000);
		
		driver.findElement(By.linkText("LOGIN")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.id("registerClick")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//input[@name='firstname']")).sendKeys("Medagam");
		Thread.sleep(1000);
		
		driver.findElement(By.xpath("//input[@name='lastname']")).sendKeys("Sai Krishna Reddy");
		Thread.sleep(1000);
		
		driver.findElement(By.xpath("//input[@name='email' and @type='email']")).sendKeys("sai2234@gmail.com");
		Thread.sleep(1000);
		
		driver.findElement(By.xpath("(//input[@name='password' and @type='password'])[2]")).sendKeys("12345678");
//	OR	driver.findElement(By.xpath("//input[@name='firstname']/../../..//input[@name='password']")).sendKeys("12345678"); 
		Thread.sleep(1000);
		
		driver.findElement(By.xpath("//input[@name='repassword']")).sendKeys("12345678");
		Thread.sleep(1000);
		
		driver.findElement(By.xpath("//input[@name='signup']")).click();
		Thread.sleep(1000);
		
		String text = driver.findElement(By.xpath("//h2[contains(text(),'Thank you for Registering.')]")).getText();
		System.out.println(text);
		Thread.sleep(2000);
		
		driver.quit();
	}

}
