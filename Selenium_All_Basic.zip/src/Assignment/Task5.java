package Assignment;
import org.openqa.selenium.WebDriver.Navigation;
/*
 * -> NAVIGATE TO giallozafferano website
 * -> come back to empty browser
 * -> AGAIN NAVIGATE TO giallozafferano website
 * -> REFRESH THE BROWSER
 * -> CLOSE THE BROWSER IN SUCH A WAY THAT IT SHOULD STOP THE SERVER
 */
import org.openqa.selenium.chrome.ChromeDriver;

public class Task5 {

	public static void main(String[] args) throws InterruptedException {
		
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.giallozafferano.it/");
		
		Navigation n = driver.navigate();
		
		n.back();
		Thread.sleep(3000);
		n.forward();
		Thread.sleep(3000);
		n.refresh();
		Thread.sleep(3000);
		
//		driver.navigate().back();
//		Thread.sleep(3000);
//		driver.navigate().forward();
//		Thread.sleep(3000);
//		driver.navigate().refresh();
//		Thread.sleep(3000);
		
		driver.quit();

	}

}
