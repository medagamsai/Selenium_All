package Assignment;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TC_001_Fb {
	public static void main(String[] args) {
		String expectedloginpage="Facebook – log in or sign up";
		String expectedusername="sai123@gmail.com";
		String expectedpassword="12345678";
		
		//Step 1 : open browser
		WebDriver driver = new ChromeDriver();
		System.out.println("browser got opened");
		driver.manage().window().maximize();
		System.out.println("browser got maximized");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		
		//step 2 : enter url
		
		driver.get("https://www.facebook.com/");
		String actualtitle = driver.getTitle();
		if(actualtitle.equals(expectedloginpage)) {
			System.out.println("successfully navigated to Facebook login page");
		}
		else {
			System.out.println("failed to navigated to Facebook login page");
		}
		
		//step3 : enter user name
		WebElement usernametextfield = driver.findElement(By.id("email"));
		usernametextfield.clear();
		usernametextfield.sendKeys(expectedusername);
		String actualusername = usernametextfield.getAttribute("value");
		if(actualusername.equals(expectedusername)) {
			System.out.println("successfully username textfield accept the data");
		}
		else {
			System.out.println("username textfield  failed to accept the data");
		}
		
		//step4 : enter password
		WebElement passwordTextField = driver.findElement(By.id("pass"));
		passwordTextField.clear();
		passwordTextField.sendKeys(expectedpassword);
		String actualpassword = passwordTextField.getAttribute("value");
		if(actualpassword.equals(expectedpassword)) {
			System.out.println("password textfield successfully accept the data");
		}else {
			System.out.println("password textfield failed to accept the data");
		}
		
		//step 5 : login button
		WebElement loginbutton = driver.findElement(By.name("login"));
		loginbutton.click();
		System.out.println("successfully navigated to home page");
		
		//step5 : close the browser
		System.out.println("browser got closed successfully");
		driver.quit();		
	}

}
