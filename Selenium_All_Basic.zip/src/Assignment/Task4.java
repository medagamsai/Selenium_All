package Assignment;
/*
 * -> NAVIGATE TO Barbequenation.com
 * -> CAPTURE THE SESSION ID OF THE WEBPAGE
 * -> CAPTURE URL OF THE WEBPAGE
 * -> CAPTURE THE SIZE OF THE WEBPAGE
 * -> CAPTURE THE POSITION OF THE WEBPAGE
 * -> PRINT IT IN CONSOLE (OUTPUT)
 * -> CLOSE THE BROWSER WILL STOP THE SERVER
 */
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.chrome.ChromeDriver;

public class Task4 {

	public static void main(String[] args) {
		
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.barbequenation.com/");
		
		String SessionId = driver.getWindowHandle();
		System.out.println(SessionId);
		
		String urlOfWebPage = driver.getCurrentUrl();
		System.out.println(urlOfWebPage);
		
		Dimension sizeOfBrowser = driver.manage().window().getSize();
		System.out.println(sizeOfBrowser);
		
		Point posOfWebPage = driver.manage().window().getPosition();
		System.out.println(posOfWebPage);
		
		driver.quit();

	}

}
