package Assignment;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Task13_xpath {
	public static void main(String[] args) throws InterruptedException {
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://www.youtube.com/");
		Thread.sleep(2000);
		
//		driver.findElement(By.xpath("//input[@placeholder='Search']")).sendKeys("rrr songs");
		driver.findElement(By.xpath("//input[@placeholder='Search']")).sendKeys("rowdy baby");
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//button[@id='search-icon-legacy']")).click();
		Thread.sleep(2000);
		
		
//		driver.findElement(By.xpath("//a[@id='video-title' and contains(@title,'Naatu Naatu Full Video Song (Telugu) [4K] ')]")).click();
//		Thread.sleep(11000);
		
		
		driver.findElement(By.xpath("//a[@id='video-title' and contains(@title,'Maari 2 - Rowdy Baby (Video Song)')]")).click();
		
		Thread.sleep(12000);
		
		
		driver.quit();
	}

}
