package Assignment;

import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Task29_window_switch {
	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
		
		driver.get("https://www.google.com/");
		String parent = driver.getWindowHandle();
		
		driver.findElement(By.name("q")).sendKeys("flowers",Keys.ENTER);
		driver.findElement(By.xpath("//div[text()='Images']")).click();
		
		//to use javascriptexecutor
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		for(;;) {
			try {
				driver.findElement(By.xpath("//div[text()='Colorful Flowers In A Vase 3 Background ...']")).click();
				break;
			} catch (Exception e) {
				js.executeScript("window.scrollBy(0,500)");
			}
			
		}
		Set<String> second = driver.getWindowHandles();
		System.out.println(second);
		driver.switchTo().window(parent);
		
		for(;;) {
			try {
				driver.findElement(By.xpath("//div[text()='37 Popular White Flowers for Home ...']")).click();
				break;
			} catch (Exception e) {
				js.executeScript("window.scrollBy(0,500)");
			}
			
		}
		Set<String> third = driver.getWindowHandles();
		System.out.println(third);
		driver.switchTo().window(parent);
		for(;;) {
			try {
				driver.findElement(By.xpath("//div[text()='Flowers Auckland | Same Day Delivery ...']")).click();
				break;
			} catch (Exception e) {
				js.executeScript("window.scrollBy(0,500)");
			}
			
		}
		
		Set<String> allfour = driver.getWindowHandles();
		System.out.println(allfour);
		
		for(String ele : third) {
			if(!ele.equals(second)) {
				driver.switchTo().window(ele);
			}
		}
	}


}
