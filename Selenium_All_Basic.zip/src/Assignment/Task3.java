package Assignment;
import java.net.MalformedURLException;
import java.net.URL;

/*
 * -> NAVIGATE TO OLIVE GARDEN WEBSITE WITHOUT USING GET METHOD
 * -> CAPTURE THE WIDTH AND HEIGHT OF THE WEBPAGE
 * -> PRINT IT IN CONSOLE (OUTPUT)
 * -> SET THE SIZE OF THE BROWSER TO 500,500
 * -> CLOSE THE BROWSER
 */
import org.openqa.selenium.Dimension;
import org.openqa.selenium.chrome.ChromeDriver;

public class Task3 {

	public static void main(String[] args) throws MalformedURLException, InterruptedException {

		ChromeDriver driver = new ChromeDriver();
		
		
//		driver.navigate().to("https://www.olivegarden.com/");
		driver.navigate().to(new URL("https://www.olivegarden.com/"));
		
		Dimension size = driver.manage().window().getSize();
		System.out.println(size);
		
//		driver.manage().window().setSize(new Dimension(500,500));
		Dimension d=new Dimension(500,500);
		driver.manage().window().setSize(d);
		
		Thread.sleep(3000);
		
		driver.close();
		
		
		
	}

}
