package Assignment;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class Task6_On_Id_Locator {

	public static void main(String[] args) throws InterruptedException {

		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://www.actitime.com/free-online-trial");
		Thread.sleep(3000);
		
		driver.findElement(By.id("FirstName")).sendKeys("medagam");
		Thread.sleep(3000);
		
		driver.findElement(By.id("LastName")).sendKeys("sai");
		Thread.sleep(3000);
		
		driver.findElement(By.id("Email")).sendKeys("sai@gmail.com");
		Thread.sleep(3000);
		
		driver.findElement(By.id("Company")).sendKeys("Qspiders");
		Thread.sleep(5000);
		
		driver.quit();
	}

}
