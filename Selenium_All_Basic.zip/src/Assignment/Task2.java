package Assignment;
/*
 * -> NAVIGATE TO YOUTUBE APPLICATION
 * -> CAPTURE THE URL OF THE WEBPAGE
 * -> PRINT IT IN CONSOLE (OUTPUT)
 * -> CLOSE THE BROWSER
 */
import org.openqa.selenium.chrome.ChromeDriver;

public class Task2 {

	public static void main(String[] args) throws InterruptedException {

		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.youtube.com/");
		String urlOfYoutube = driver.getCurrentUrl();
		System.out.println(urlOfYoutube);
		Thread.sleep(3000);
		driver.close();
	}

}
