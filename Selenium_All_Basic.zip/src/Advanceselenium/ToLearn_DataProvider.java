package Advanceselenium;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class ToLearn_DataProvider {
	
	@DataProvider(name="cred")
	public String[][] tosenddata() {
		String [][] saar = {
				{"sai@gmail.com","sai@123"},
				{"krishna@gmail.com","krishna@123"},
				{"medagam@gmail.com","medagam@123"}
				
		}; 
		return saar;
	}
	
	@Test(dataProvider = "cred")
	public void tologin(String username,String Password) {
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(12));
		
		driver.get("https://www.facebook.com/");
		driver.findElement(By.id("email")).sendKeys(username);
		driver.findElement(By.id("pass")).sendKeys(Password);
				
	}
	

}
