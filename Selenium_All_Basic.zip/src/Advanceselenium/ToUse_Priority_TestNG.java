package Advanceselenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class ToUse_Priority_TestNG {
//	public class ToLearnTestNG {
//
//		@Test(priority = -1)
//		public void cricbuzz() {
//			WebDriver driver = new ChromeDriver();
//			driver.get("https://www.cricbuzz.com/");
//			Reporter.log("cricbuzz got executed", true);
//			driver.quit();
//		}
//		
//		@Test(priority = 0)
//		public void baskinrobbins() {
//			WebDriver driver = new ChromeDriver();
//			driver.get("https://baskinrobbinsindia.com/");
//			Reporter.log("baskin got executed", true);
//			driver.quit();
//		}
//		
//		@Test(priority = -2)
//		public void amazon() {
//			WebDriver driver = new ChromeDriver();
//			driver.get("https://www.amazon.in/");
//			Reporter.log("amazon got executed", true);
//			driver.quit();
//			
//		}
//
//}
//	public class tolearntestngprio{
		
		@Test(priority = 1)
		public void cricbuzz() {
			WebDriver driver = new ChromeDriver();
			driver.get("https://www.cricbuzz.com/");
			Reporter.log("cricbuzz got executed",true);
			driver.quit();
		}
		
			@Test(priority = 0)
			public void baskinrobbin() {
				WebDriver driver = new ChromeDriver();
				driver.get("https://baskinrobbinsindia.com/");
				Reporter.log("Baskin robbin got executed",true);
				driver.quit();
			}
			
			@Test(priority = 2)
			public void amazon() {
				WebDriver driver = new ChromeDriver();
				driver.get("https://www.amazon.in/");
				Reporter.log("amazon got executed",true);
				driver.quit();
				
			}
		
	//}
}
