package Advanceselenium;
// how many times to run//default is 1
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class ToUse_invocationCount {
	
//	@Test(priority = 0,invocationCount = 2)
//	public void cricbuzz() {
//		WebDriver driver = new ChromeDriver();
//		driver.get("https://www.cricbuzz.com/");
//		Reporter.log("cricbuzz got executed", true);
//		driver.quit();
//	}
//	
//	@Test(invocationCount = 1)
//	public void baskinrobbins() {
//		WebDriver driver = new ChromeDriver();
//		driver.get("https://baskinrobbinsindia.com/");
//		Reporter.log("baskin got executed", true);
//		driver.quit();
//	}
//	
//	@Test(invocationCount = 2)
//	public void amazon() {
//		WebDriver driver = new ChromeDriver();
//		driver.get("https://www.amazon.in/");
//		Reporter.log("amazon got executed", true);
//		driver.quit();
//		
//	}
	
	@Test(invocationCount = 2)
	public void cricbuzz() {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.cricbuzz.com/");
		Reporter.log("cricbuzz got executed",true);
		driver.quit();
	}
	@Test(invocationCount = 3)
	public void baskinrobbin() {
		WebDriver driver = new ChromeDriver();
		driver.get("https://baskinrobbinsindia.com/");
		Reporter.log("baskin robbin got executed",true);
		driver.quit();
	}
	
	@Test(invocationCount = 2)
	public void amazon() {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.amazon.in/");
		Reporter.log("amazon got executed",true);
		driver.quit();
	}

}
