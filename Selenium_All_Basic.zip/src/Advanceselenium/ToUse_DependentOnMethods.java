package Advanceselenium;

import org.testng.Reporter;
import org.testng.annotations.Test;

public class ToUse_DependentOnMethods {
	
	@Test
	public void CreateAccount() {
		Reporter.log("Account created successfully", true);
	}
	
	@Test(dependsOnMethods  = "CreateAccount")
	public void editAccount() {
		Reporter.log("Account edited successfully", true);
	}
	
	@Test(dependsOnMethods  ="editAccount")
	public void deleteAccount() {
		Reporter.log("Account deleted successfully", true);
	}
	
//	@Test(dependsOnMethods  ={"editAccount","CreateAccount"})    //Depend more than one method
//	public void deleteAccount() {
//		Reporter.log("Account deleted successfully", true);
//	}

}
