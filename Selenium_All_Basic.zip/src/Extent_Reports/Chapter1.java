package Extent_Reports;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;

import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class Chapter1 {
	
	public static void main(String[] args) throws IOException {
		ExtentReports ep = new ExtentReports();
		ExtentSparkReporter esr=new ExtentSparkReporter("report.html");
		ep.attachReporter(esr);
		
		ep.flush();
		Desktop.getDesktop().browse(new File("report.html").toURI());
	}

}
