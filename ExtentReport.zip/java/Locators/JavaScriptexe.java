package Locators;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

public class JavaScriptexe extends BaseClass {

	@Ignore
	@Test
	public void jsp() throws InterruptedException {
		driver.get("https://www.facebook.com/r.php/");
		WebElement hidden = driver.findElement(By.id("custom_gender"));
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].value='have a nice day'", hidden);
//	Thread.sleep(4000);
	}
	
	@Test
	public void scroll() throws InterruptedException {
		driver.get("https://in.images.search.yahoo.com/search/images;_ylt=Awr1RZVhYgVpMQIAkRO7HAx.;_ylu=Y29sbwNzZzMEcG9zAzEEdnRpZAMEc2VjA3BpdnM-?p=wallpaper+for+laptop&fr2=piv-web&type=E211IN714G0-E211IN714G0&fr=mcafee");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,500)");
		Thread.sleep(4000);

	}
}
