package Locators;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class Iframesexe extends BaseClass{
	
	@Test
	public void fra() throws InterruptedException {
		driver.get("https://www.globalsqa.com/demo-site/draganddrop/");
//		WebElement ele = driver.findElement(By.xpath("(//iframe[@class='demo-frame' and @width='700'])[1]"));
//		driver.switchTo().frame(ele);
		driver.findElement(By.id("Accepted Elements")).click();
		Thread.sleep(2000);
		driver.switchTo().defaultContent();
		driver.findElement(By.id("menu-item-53896")).click();
		Thread.sleep(2000);
	}

}
