package Locators;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.testng.annotations.Ignore;
import org.testng.annotations.Test;
@Ignore
public class DataDrivenexe extends BaseClass {
	
	@Test
	public void data() throws EncryptedDocumentException, IOException {
		
		FileInputStream fis = new FileInputStream("./ExcelData/sai.xlsx");
		Workbook wb = WorkbookFactory.create(fis);
		
		String link = wb.getSheet("Sheet1").getRow(0).getCell(0).toString();
		String un = wb.getSheet("Sheet1").getRow(1).getCell(0).toString();
		
		driver.get(link);
	}

}
