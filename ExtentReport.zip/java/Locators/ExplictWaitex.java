package Locators;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class ExplictWaitex extends BaseClass{
	
	@Test(groups = "smoke")
	public void exp() {
		driver.get("https://www.shoppersstack.com/products_page/26");
		driver.findElement(By.id("Check Delivery")).sendKeys("500008");
		WebElement expcheck = driver.findElement(By.id("Check"));
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.elementToBeClickable(expcheck));
		expcheck.click();
		System.out.println("sai123");
		
	}

}
