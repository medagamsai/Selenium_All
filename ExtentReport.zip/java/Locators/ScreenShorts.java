package Locators;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.io.FileHandler;
import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

public class ScreenShorts extends BaseClass{
	
	@Test(groups = "functional")
	public void entire() throws IOException {
		driver.get("https://www.facebook.com/");
		driver.findElement(By.id("email")).sendKeys("sai@123");
	//	driver.findElement(By.xpath("//div[@id='email_container']/div[2]"));
		
		
		TakesScreenshot ts = (TakesScreenshot) driver;
		File temp = ts.getScreenshotAs(OutputType.FILE);
		File per= new File("./error/sai.png");
		FileHandler.copy(temp, per);
	
	}
	
	@Test(groups = "functional")
	public void element() throws IOException {
		driver.get("https://www.facebook.com/");
		WebElement ele = driver.findElement(By.id("email"));
		
		File temp = ele.getScreenshotAs(OutputType.FILE);
		File per = new File("./error/sai1.png");
		FileHandler.copy(temp, per);
		
		
	}

}
