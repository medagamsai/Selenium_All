package Locators;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class IDLOCATOR extends BaseClass{

	@Test (groups = "smoke")
	public void fb() {
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(4));
		driver.get("https://www.facebook.com/");
		driver.findElement(By.id("email")).sendKeys("sai@123" ,Keys.ENTER);
		
	}
	
	@Test (groups = "smoke")
	public void text() {
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(4));
		driver.get("https://www.facebook.com/");
		driver.findElement(By.id("email")).sendKeys("sai@123" ,Keys.ENTER);
		String text = driver.findElement(By.xpath("//div[@id='email_container']/div[2]")).getText();
		System.out.println(text);
		
		Reporter.log("true",true);
	}
}
