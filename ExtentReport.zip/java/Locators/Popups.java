package Locators;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

public class Popups extends BaseClass {
	@Ignore
	@Test(priority = 1)
	public void noti() {
		ChromeOptions settings = new ChromeOptions();
//		settings.addArguments("--disable-notifications");
		settings.addArguments("--incognito");
		WebDriver driver = new ChromeDriver(settings);
		driver.get("https://www.yatra.com/");
	}
	
	@Ignore
	@Test
	public void hidden() {
		
driver.get("https://www.makemytrip.com/");
		
		driver.findElement(By.xpath("//span[@data-cy='closeModal']")).click();
		driver.findElement(By.xpath("//label[@for='departure']")).click();
		
		for(;;) {
			try {
				driver.findElement(By.xpath("//div[text()='June 2026']/../..//p[text()='9']")).click();
			}
			catch (Exception e) {
				driver.findElement(By.xpath("//span[@aria-label='Next Month']")).click();
			}
		}
		
	}
	
	@Test
	public void auth() {
		driver.get("https://admin:admin@the-internet.herokuapp.com/basic_auth");
	}

}
