package Locators;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class DropDownSelect extends BaseClass{
	
	@Test(invocationCount = 4 , threadPoolSize = 4)
	public void sel() {
		driver.get("https://www.facebook.com/r.php/");
		WebElement day = driver.findElement(By.id("day"));
		WebElement month = driver.findElement(By.id("month"));
		WebElement year = driver.findElement(By.id("year"));
		
		Select dayse=new Select(day);
		Select monse=new Select(month);
		Select yearse=new Select(year);
		
		dayse.selectByIndex(19);
		monse.selectByValue("4");
		yearse.selectByVisibleText("2002");
		
	}
	
	@Test(invocationCount = 4 , threadPoolSize = 2)
	public void sele() {
		driver.get("https://www.facebook.com/r.php/");
		WebElement day = driver.findElement(By.id("day"));
		WebElement month = driver.findElement(By.id("month"));
		WebElement year = driver.findElement(By.id("year"));
		
		Select dayse=new Select(day);
		Select monse=new Select(month);
		Select yearse=new Select(year);
		
		dayse.selectByIndex(19);
		monse.selectByValue("4");
		yearse.selectByVisibleText("2002");
		
	}

}
