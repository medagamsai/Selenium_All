package Locators;

import java.lang.classfile.instruction.ReturnInstruction;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Actionsexe extends BaseClass{
	
	@Test(dataProvider = "sai")
	public void act(String link) {
		driver.get(link);
		WebElement ele = driver.findElement(By.xpath("(//iframe[@class='demo-frame' and @width='700'])[1]"));
		driver.switchTo().frame(ele);
		
		WebElement img1 = driver.findElement(By.xpath("//img[@alt='The peaks of High Tatras']"));
		WebElement img2 = driver.findElement(By.xpath("//img[@alt='The chalet at the Green mountain lake']"));
		WebElement img3 = driver.findElement(By.xpath("//img[@alt='Planning the ascent']"));
		WebElement img4 = driver.findElement(By.xpath("//img[@alt='On top of Kozi kopka']"));
		
		
		WebElement trash = driver.findElement(By.id("trash"));
		
		
		Actions a = new Actions(driver);
		
		a.dragAndDrop(img4, trash).perform();
	}
	
	@DataProvider(name="sai")
	public 	String[]  me(){
		String[] da= {"https://www.globalsqa.com/demo-site/draganddrop/"};
		return da;	
		
	}
	

}
