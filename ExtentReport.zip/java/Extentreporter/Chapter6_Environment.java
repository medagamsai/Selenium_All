package Extentreporter;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.CodeLanguage;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.mysql.cj.x.protobuf.MysqlxConnection.Capabilities;

import groovyjarjarantlr4.v4.parse.BlockSetTransformer.setAlt_return;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Chapter6_Environment {
	
	public static void main(String[] args) throws IOException {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		org.openqa.selenium.Capabilities capabilities=((RemoteWebDriver)driver).getCapabilities();
		ExtentReports extentReport = new ExtentReports();
		ExtentSparkReporter extentspark=new ExtentSparkReporter("report.html");
		extentReport.attachReporter(extentspark);
		
		
		extentReport.setSystemInfo("os", System.getProperty("os.name"));
		extentReport.setSystemInfo("Java Version ", System.getProperty("java.version"));
		extentReport.setSystemInfo("Browser", System.getProperty("os.name"));
		extentReport.setSystemInfo("os", System.getProperty("os.name"));
		extentReport.setSystemInfo("os", capabilities.getBrowserName() + capabilities.getBrowserVersion());
		
		
		extentReport
		.createTest("Test 1","Test dec")
		.assignAuthor("sai")
		.assignCategory("smoke")
		.assignDevice("chrome")
		.pass("This is a passed test");
		
		
		extentReport
		.createTest("Test 2","Test dec")
		.assignAuthor("krishna")
		.assignCategory("sanity")
		.assignDevice("edge")
		.fail("This is a passed test");
		
		extentReport
		.createTest("Test 3","Test dec")
		.assignAuthor("sai","krishna","reddy")
		.assignCategory("smoke","sanity","regression")
		.assignDevice("chrome","edge","firefox")
		.pass("This is a passed test");
		
		
		extentReport
		.createTest("Test 4","Test dec")
		.assignAuthor(new String[] {"sai","me","to"})
		.assignCategory(new String[] {"smoke","regression"})
		.assignDevice("edge")
		.fail("This is a passed test");
		
		extentReport.flush();
		Desktop.getDesktop().browse(new File("report.html").toURI());
	}

}
