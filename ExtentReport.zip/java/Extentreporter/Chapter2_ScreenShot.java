package Extentreporter;

import static org.testng.Assert.fail;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Chapter2_ScreenShot {
	static WebDriver driver;
	public static void main(String[] args) throws IOException {
		ExtentReports extentReport = new ExtentReports();
		ExtentSparkReporter extentspark=new ExtentSparkReporter("report.html");
		extentReport.attachReporter(extentspark);
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://extentreports.com/");
		
		String base64 = capturescreenshot();
		String path = capturescreenshot("google.jpg");
		
		extentReport
		.createTest("ScreenShot Test 1","This is for attaching")
		.info("This is a info Message")
		.addScreenCaptureFromBase64String(base64);
		
		
		extentReport
		.createTest("ScreenShot Test 2","This is for attaching")
		.info("This is a info message")
		.addScreenCaptureFromPath(path);
		
		extentReport
		.createTest("ScreenShot Test3", "This is for attachment")
		.info("This is ingo message")
		.addScreenCaptureFromBase64String(base64, "google home page");
		
		extentReport
		.createTest("ScreenShot Test4", "This is attachment")
		.info("This is info message")
		.addScreenCaptureFromPath(path, "Google homepage");
		
		extentReport
		.createTest("ScreenShot Test5", "This is attachment")
		.info("This is info message")
		.addScreenCaptureFromPath(path, "Google homepage1")
		.addScreenCaptureFromPath(path, "Google homepage2")
		.addScreenCaptureFromPath(path, "Google homepage3");
		
		
		
		extentReport
		.createTest("ScreenShot Test6", "This is attachment")
		.info("This is info message")
		.fail(MediaEntityBuilder.createScreenCaptureFromBase64String(base64).build())
		.fail(MediaEntityBuilder.createScreenCaptureFromPath(path).build())
		.fail(MediaEntityBuilder.createScreenCaptureFromPath(path, "google homepage1").build())
		.fail(MediaEntityBuilder.createScreenCaptureFromBase64String(base64, "Google Homepage2").build());
		
		
		extentReport
		.createTest("ScreenShot Test7", "This is attachment")
		.info("This is info message")
		.fail("This ia base64",MediaEntityBuilder.createScreenCaptureFromBase64String(base64).build())
		.fail("this ispath",MediaEntityBuilder.createScreenCaptureFromPath(path).build())
		.fail("This is path with data",MediaEntityBuilder.createScreenCaptureFromPath(path, "google homepage1").build())
		.fail("This is base with data",MediaEntityBuilder.createScreenCaptureFromBase64String(base64, "Google Homepage2").build());

		
		Throwable t = new Throwable("This is a Throwable exception");
		
		extentReport
		.createTest("ScreenShot Test8", "This is attachment")
		.info("This is info message")
		.fail(t,MediaEntityBuilder.createScreenCaptureFromBase64String(base64).build())
		.fail(t,MediaEntityBuilder.createScreenCaptureFromPath(path).build())
		.fail(t,MediaEntityBuilder.createScreenCaptureFromPath(path, "google homepage1").build())
		.fail(t,MediaEntityBuilder.createScreenCaptureFromBase64String(base64, "Google Homepage2").build());

		
		extentReport.flush();
		driver.quit();
		Desktop.getDesktop().browse(new File("report.html").toURI());
	}
	
	public static String capturescreenshot() throws IOException {
		TakesScreenshot ts = (TakesScreenshot) driver;
		String base64 = ts.getScreenshotAs(OutputType.BASE64);
		System.out.println("ScreenShot Saved successfully");
		return base64;
		
	}
	
	public static String capturescreenshot(String file)  {
		TakesScreenshot ts = (TakesScreenshot) driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		File dest = new File("./Screenshot"+file);
		try {
			FileUtils.copyFile(source, dest);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("ScreenShot Saved successfully");
		return dest.getAbsolutePath();
		
	}
	
	

}
