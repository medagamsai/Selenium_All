package Extentreporter;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class Chapter1 {
	public static void main(String[] args) throws IOException {
//		WebDriver driver = new ChromeDriver();
		ExtentReports ep = new ExtentReports();
		ExtentSparkReporter esr=new ExtentSparkReporter("report.html");
		ep.attachReporter(esr);
		
		ExtentTest Test1 = ep.createTest("Test1");
		Test1.pass("This is pass");
		
		
		ExtentTest Test2 = ep.createTest("Test2");
		Test2.log(Status.FAIL, "This is fail");
		
		ep.createTest("Test3").skip("This is skip");
		
		ep.flush();
		Desktop.getDesktop().browse(new File("report.html").toURI());
	}

}
