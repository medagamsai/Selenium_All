package Extentreporter;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.CodeLanguage;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.ViewName;
import com.mysql.cj.x.protobuf.MysqlxConnection.Capabilities;

import groovyjarjarantlr4.v4.parse.BlockSetTransformer.setAlt_return;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Chapter8_ExtentReport_Fail_Skip_Passed {
	public static void main(String[] args) throws IOException {
		ExtentReports extentReport = new ExtentReports();
		ExtentSparkReporter spark_all=new ExtentSparkReporter("allreport.html");
		ExtentSparkReporter spark_failed=new ExtentSparkReporter("failed.html");
		spark_failed.filter().statusFilter().as(new Status[] {Status.FAIL}).apply();
		ExtentSparkReporter spark_skipandwarning=new ExtentSparkReporter("skipAndWarning.html");
		spark_skipandwarning.filter().statusFilter().as(new Status[] {
			Status.SKIP,
			Status.WARNING
		});
//		extentspark.viewConfigurer().viewOrder().as(new ViewName[] { 
//				ViewName.DASHBOARD,
//				ViewName.TEST,
//	//			ViewName.EXCEPTION,
//				ViewName.CATEGORY,
//				ViewName.DEVICE
//				
//				
//		}).apply();
		extentReport.attachReporter(spark_all,spark_failed,spark_skipandwarning);
		
		
		
		
		extentReport
		.createTest("Test 1","Test dec")
		.assignAuthor("sai")
		.assignCategory("smoke")
		.assignDevice("chrome")
		.pass("This is a passed test");
		
		
		extentReport
		.createTest("Test 2","Test dec")
		.assignAuthor("krishna")
		.assignCategory("sanity")
		.assignDevice("edge")
		.fail("This is a passed test");
		
		extentReport
		.createTest("Test 3","Test dec")
		.assignAuthor("sai","krishna","reddy")
		.assignCategory("smoke","sanity","regression")
		.assignDevice("chrome","edge","firefox")
		.warning("This is warning");
		
		
		extentReport
		.createTest("Test 4","Test dec")
		.assignAuthor(new String[] {"sai","me","to"})
		.assignCategory(new String[] {"smoke","regression"})
		.assignDevice("edge")
		.skip("This is skip");
		
		extentReport.flush();
		Desktop.getDesktop().browse(new File("allreport.html").toURI());
		Desktop.getDesktop().browse(new File("failed.html").toURI());
		Desktop.getDesktop().browse(new File("skipAndWarning.html").toURI());
	}

}
