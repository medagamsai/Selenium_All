package SparkReport;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.annotations.Test;

public class Amazon extends BaseClassExtentReport{
	
	@Test(testName = "sai" , groups = {"smoke" , "sanity"})
	public void google() {
		driver.get("https://www.google.com/");
		extentTest.info("Navigated to google");
		driver.findElement(By.name("q")).sendKeys("mimics",Keys.ENTER);
		extentTest.info("Enter the text in search");
		
	}
	
	@Test(testName = "krishna" , groups = {"smoke" , "Regression"})
	public void ama() {
		driver.get("https://www.amazon.in/s?k=shoes");
		extentTest.info("Navigated to google");
		
	}
	
	@Test(testName = "reddy" , groups = {"functional" , "sanity"})
	public void so() {
		driver.get("https://www.flipkart.com/search?q=laptop");
		extentTest.info("Navigated to google");
		
	}
	

}
